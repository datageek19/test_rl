from typing import Optional, Dict, Any
import json


def execute_salesforce_query(query: str) -> Dict[str, Any]:
    """
    Executes a SOQL query against Salesforce Data Cloud objects using REST API.
   
    Args:
        query: The SOQL query to execute
       
    Returns:
        A dictionary containing query results with status and data
    """
    import urllib.parse
    import os
    
    username = os.getenv('SALESFORCE_USERNAME', 'amit.cm.sharma@accenture.com.retaildev2')
    password = os.getenv('SALESFORCE_PASSWORD', 'Sfdc@1234')
    security_token = os.getenv('SALESFORCE_SECURITY_TOKEN', 'cMEynCTKSdYQ6O4XgYaQRGub')
    client_id = os.getenv('SALESFORCE_CLIENT_ID', '3MVG9HbBKF.OyqUfyN2jBqofJlB9XvOb6zkPmyTi9i2ghSKC27tM4.xvQQVHo7p6HrNvD8LFKggsAljAKE0ZY')
    client_secret = os.getenv('SALESFORCE_CLIENT_SECRET', '745CFA2493729D1246A0F36738C24EA1338C91D2C2FA4A438885FB92BAA8EC11')
    
    is_sandbox = os.getenv('SALESFORCE_SANDBOX', 'true').lower() == 'true'
    instance_url = 'https://accenture51--retaildev2.sandbox.my.salesforce.com' if is_sandbox else 'https://login.salesforce.com'
    
    try:
        auth_url = f"{instance_url}/services/oauth2/token"
        auth_data = f"grant_type=password&client_id={client_id}&client_secret={client_secret}&username={username}&password={password}{security_token}"
        
        auth_headers = {
            'Content-Type': 'application/x-www-form-urlencoded'
        }
        
        auth_res = ces_requests.request(
            method=HttpMethod.POST,
            url=auth_url,
            data=auth_data,
            headers=auth_headers
        )
        
        # DEBUG: Log the auth response status
        auth_status = auth_res.status_code
        
        try:
            auth_res.raise_for_status()
        except Exception as e:
            # Return detailed error for debugging
            try:
                error_body = auth_res.json()
            except:
                error_body = auth_res.text
                
            return {
                "success": False,
                "status": "error",
                "message": "Failed to authenticate with Salesforce",
                "error": error_body,
                "status_code": auth_status,
                "debug_info": {
                    "auth_url": auth_url,
                    "username": username,
                    "has_password": bool(password),
                    "has_token": bool(security_token),
                    "is_sandbox": is_sandbox
                }
            }
        
        auth_response = auth_res.json()
        
        # DEBUG: Check what keys are in the response
        response_keys = list(auth_response.keys())
        
        access_token = auth_response.get('access_token')
        instance_url = auth_response.get('instance_url')
        
        # More detailed error if no access token
        if not access_token:
            return {
                "success": False,
                "status": "error",
                "message": "No access token received from Salesforce",
                "debug_info": {
                    "response_keys": response_keys,
                    "full_response": auth_response,
                    "status_code": auth_status
                }
            }
        
        encoded_query = urllib.parse.quote(query)
        query_url = f"{instance_url}/services/data/v59.0/query?q={encoded_query}"
        
        query_headers = {
            'Authorization': f'Bearer {access_token}',
            'Content-Type': 'application/json'
        }
        
        query_res = ces_requests.request(
            method=HttpMethod.GET,
            url=query_url,
            headers=query_headers
        )
        
        try:
            query_res.raise_for_status()
        except Exception:
            try:
                err_json = query_res.json()
                return {
                    "success": False,
                    "status": "error",
                    "message": "Query execution failed",
                    "error": err_json,
                    "status_code": query_res.status_code
                }
            except:
                return {
                    "success": False,
                    "status": "error",
                    "message": "Query execution failed",
                    "error": query_res.text,
                    "status_code": query_res.status_code
                }
        
        result = query_res.json()
        
        if result.get('totalSize', 0) == 0:
            return {
                "success": True,
                "status": "not_found",
                "message": "No records found for the given query",
                "data": {
                    "totalSize": 0,
                    "records": []
                }
            }
        
        return {
            "success": True,
            "status": "success",
            "data": {
                "totalSize": result.get('totalSize', 0),
                "records": result.get('records', [])
            }
        }
        
    except Exception as e:
        return {
            "success": False,
            "status": "error",
            "message": f"Error executing query: {str(e)}",
            "exception_type": type(e).__name__
        }