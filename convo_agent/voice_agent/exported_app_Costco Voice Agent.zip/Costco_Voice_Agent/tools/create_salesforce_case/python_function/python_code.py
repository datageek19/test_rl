from typing import Optional, Dict, Any
import json


def create_salesforce_case(case_data: Dict[str, Any], async_mode: bool = True) -> Dict[str, Any]:
    """
    Creates a case in Salesforce with the provided case data using REST API.
    
    Args:
        case_data: Dictionary containing case fields (Subject, Description, Status, Origin, etc.)
        async_mode: If True, creates case without waiting. If False, waits for completion.
        
    Returns:
        A dictionary with success message and case_id (if successful)
    
    Example case_data:
        {
            'Subject': 'Case Subject',
            'Description': 'Case description',
            'Status': 'New',
            'Origin': 'Phone',
            'SuppliedEmail': 'customer@example.com',
            'Priority': 'High'
        }
        
    Notes:
        This function uses `ces_requests` for HTTP calls and Salesforce REST API.
        Requires OAuth2 authentication with Salesforce.
    """
    # Local imports (required in CES tool execution context)
    import os
    
    username = os.getenv('SALESFORCE_USERNAME', 'amit.cm.sharma@accenture.com.retaildev2')
    password = os.getenv('SALESFORCE_PASSWORD', 'Sfdc@1234')
    security_token = os.getenv('SALESFORCE_SECURITY_TOKEN', 'cMEynCTKSdYQ6O4XgYaQRGub')
    client_id = os.getenv('SALESFORCE_CLIENT_ID', '3MVG9HbBKF.OyqUfyN2jBqofJlB9XvOb6zkPmyTi9i2ghSKC27tM4.xvQQVHo7p6HrNvD8LFKggsAljAKE0ZY')
    client_secret = os.getenv('SALESFORCE_CLIENT_SECRET', '745CFA2493729D1246A0F36738C24EA1338C91D2C2FA4A438885FB92BAA8EC11')
    
    # Use sandbox or production
    is_sandbox = os.getenv('SALESFORCE_SANDBOX', 'true').lower() == 'true'
    instance_url = 'https://accenture51--retaildev2.sandbox.my.salesforce.com' if is_sandbox else 'https://login.salesforce.com'
    
    try:
        # Step 1: Authenticate with Salesforce to get access token
        auth_url = f"{instance_url}/services/oauth2/token"
        
        # Format data as URL-encoded string (required for Salesforce)
        auth_data = f"grant_type=password&client_id={client_id}&client_secret={client_secret}&username={username}&password={password}{security_token}"
        
        auth_headers = {
            'Content-Type': 'application/x-www-form-urlencoded'
        }
        
        auth_res = ces_requests.request(
            method=HttpMethod.POST,
            url=auth_url,
            data=auth_data,
            headers=auth_headers
        )
        
        try:
            auth_res.raise_for_status()
        except Exception:
            return {
                "success": False,
                "status": "error",
                "message": "Failed to authenticate with Salesforce",
                "error": auth_res.text,
                "status_code": auth_res.status_code
            }
        
        auth_response = auth_res.json()
        access_token = auth_response.get('access_token')
        instance_url = auth_response.get('instance_url')
        
        if not access_token:
            return {
                "success": False,
                "status": "error",
                "message": "No access token received from Salesforce"
            }
        
        # Step 2: Create Case using REST API
        case_url = f"{instance_url}/services/data/v59.0/sobjects/Case"
        
        case_headers = {
            'Authorization': f'Bearer {access_token}',
            'Content-Type': 'application/json'
        }
        
        case_res = ces_requests.request(
            method=HttpMethod.POST,
            url=case_url,
            data=json.dumps(case_data),
            headers=case_headers
        )
        
        try:
            case_res.raise_for_status()
        except Exception:
            try:
                err_json = case_res.json()
                return {
                    "success": False,
                    "status": "error",
                    "message": "Failed to create case",
                    "error": err_json,
                    "status_code": case_res.status_code
                }
            except:
                return {
                    "success": False,
                    "status": "error",
                    "message": "Failed to create case",
                    "error": case_res.text,
                    "status_code": case_res.status_code
                }
        
        result = case_res.json()
        
        if result.get('success'):
            case_id = result.get('id')
            return {
                "success": True,
                "status": "success",
                "message": "Case created successfully",
                "case_id": case_id
            }
        else:
            return {
                "success": False,
                "status": "error",
                "message": "Failed to create case",
                "details": result
            }
        
    except Exception as e:
        return {
            "success": False,
            "status": "error",
            "message": f"Error creating case: {str(e)}",
            "status_code": None
        }
