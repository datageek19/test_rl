from typing import Optional

def send_twilio_sms(
    to_number: str,
    message_body: str,
) -> Optional[str]:
    """
    Sends an SMS message using the Twilio API with Basic Authentication.

    Args:
        to_number: The destination phone number.
        message_body: The text content of the SMS.

    Returns:
        A string containing the Twilio message SID on success, or None if an error occurs.

    Notes:
        This function uses `ces_requests`, which works similarly to the `requests`
        library. Twilio requires Basic Auth where the username is the Account SID
        and the password is the Auth Token.
    """
    # Local import (required in CES tool execution context)
    import base64

    account_sid = 'test'
    auth_token = 'test'

    # Build Basic Auth header manually
    userpass = f"{account_sid}:{auth_token}".encode("utf-8")
    basic_auth_header = base64.b64encode(userpass).decode("utf-8")

    headers = {
        "Authorization": f"Basic {basic_auth_header}",
        "Content-Type": "application/x-www-form-urlencoded",
    }
    
    url = f"https://api.twilio.com/2010-04-01/Accounts/{account_sid}/Messages.json"

    data = {
        "From": '+12029309922',
        "To": '+15715441605',
        "Body": 'Costco: Your verification code is 454545',
    }

    try:
        res = ces_requests.request(
            method=HttpMethod.POST,
            url=url,
            data=data,
            headers=headers,
        )

        # If Twilio returns a non-2xx status, we capture and return details
        try:
            res.raise_for_status()
        except Exception:
            # Twilio sends JSON error bodies like:
            # { "code": 12345, "message": "Invalid To number", ... }
            try:
                err_json = res.json()
                return {
                    "success": False,
                    "status_code": res.status_code,
                    "error": err_json.get("message"),
                    "twilio_code": err_json.get("code"),
                    "raw": err_json,
                }
            except:
                # non-JSON error
                return {
                    "success": False,
                    "status_code": res.status_code,
                    "error": res.text,
                }

        # Success → extract message SID
        msg = res.json()
        return {
            "success": True,
            "sid": msg.get("sid"),
            "raw": msg,
        }

    except Exception as e:
        return {
            "success": False,
            "error": str(e),
            "status_code": None,
        }