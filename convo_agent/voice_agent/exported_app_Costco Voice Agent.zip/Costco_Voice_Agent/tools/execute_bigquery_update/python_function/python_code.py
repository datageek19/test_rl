def execute_bigquery_update(query: str) -> dict:
    """
    Execute BigQuery DML operations (UPDATE, INSERT, DELETE) in CES.
    
    CES automatically authenticates using Application Default Credentials (ADC).
    The bigquery.Client() automatically picks up CES's service account credentials.
    
    Args:
        query: SQL query string (e.g., "UPDATE dataset.table SET column = 'value' WHERE id = 1")
    
    Returns:
        dict: Result with success status and rows affected
        
    Usage in CES:
        1. Copy this function into a "Python code" tool in CES
        2. Name the tool: execute_bigquery_update
        3. Ensure CES service account has BigQuery permissions
        4. The agent will automatically call it when users request updates
    """
    from google.cloud import bigquery
    
    try:
        client = bigquery.Client(project='acn-ngca-client1')
        
        query_job = client.query(query)
        
        result = query_job.result()
        
        rows_affected = query_job.num_dml_affected_rows
        
        if rows_affected is not None:
            return {
                "success": True,
                "message": f"Query executed successfully. {rows_affected} rows affected.",
                "rows_affected": int(rows_affected)
            }
        else:
            row_count = query_job.total_rows or 0
            return {
                "success": True,
                "message": f"Query executed successfully. {row_count} rows returned.",
                "row_count": int(row_count)
            }
            
    except Exception as e:
        error_message = str(e)
        
        if "Permission denied" in error_message or "403" in error_message:
            return {
                "success": False,
                "message": f"Permission denied. Ensure CES service account has BigQuery roles (jobUser, dataEditor). Error: {error_message}"
            }
        elif "not found" in error_message.lower():
            return {
                "success": False,
                "message": f"Table or dataset not found. Check your query syntax. Error: {error_message}"
            }
        else:
            return {
                "success": False,
                "message": f"BigQuery error: {error_message}"
            }