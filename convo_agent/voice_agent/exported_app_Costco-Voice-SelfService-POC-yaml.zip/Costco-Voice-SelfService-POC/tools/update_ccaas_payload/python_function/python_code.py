from pydantic import BaseModel, Field
from typing import Optional, Dict, Any

def update_ccaas_payload(summary: str, escalation_reason: str, main_topic: str) -> Dict[str, Any]:
  """
  update the TELEPHONY_PAYLOAD variable with the conversation summary, escalation reason and main_contact_topic and returns the updated TELEPHONY_PAYLOAD.

  Args:
    summary: The summary of the conversation as of now.
    escalation_reasaon: The short description of the escalation reason
    main_topic: The main topic of the interraction.

  Returns:
    A dictionary containing the updated TELEPHONY_PAYLOAD
  """
  print(f"update_ccaas_payload")

  payload = {"ujet": {"session_variable": {"capture_target": "payload","payload": {"summary": "This is a summary","escalation_reason": "This is the escalation_reason"},"capture_type": ["field","agent"]},"action": "escalation","type": "action","menu_id": "33","escalation_reason": "by_virtual_agent"}}

  # --- Start of update ---
  # Conditionally update the payload if the input parameters are not None.
  
  if summary is not None:
    payload['ujet']['session_variable']['payload']['summary'] = summary
  
  if escalation_reason is not None:
    payload['ujet']['session_variable']['payload']['escalation_reason'] = escalation_reason
  
  if main_topic is not None:
    payload['ujet']['session_variable']['payload']['main_topic'] = main_topic
  
  # --- End of update ---

  # Assuming 'context' is a globally available or passed-in object.
  # The following line updates the state of that object.
  context.state["TELEPHONY_PAYLOAD"] = payload

  # other ways to set the "customer_profile" are:
  # context.variables["customer_profile"] = profile.model_dump()
  # set_variable("customer_profile", profile.model_dump())

  return context.state["TELEPHONY_PAYLOAD"]