def products() -> str:
    return "Your products query has been received successfully."
