def create_salesforce_case(subject: str, origin: str, reason: str) -> dict:
    """
    Creates a Case in Salesforce using access token stored in session state.

    Args:
        subject: Case subject
        origin: Case origin (Web, Phone, Chat, etc.)
        reason: Reason for the case

    Returns:
        dict with success flag and case details
    """
    try:
        access_token = context.state.get("salesforce_access_token")
        instance_url = context.state.get("salesforce_instance_url")

        if not access_token or not instance_url:
            return {
                "success": False,
                "message": "Salesforce authentication is missing."
            }

        url = f"{instance_url}/services/data/v61.0/sobjects/Case"

        headers = {
            "Authorization": f"Bearer {access_token}",
            "Content-Type": "application/json"
        }

        payload = {
            "Subject": subject,
            "Origin": origin,
            "Reason": reason
        }

        response = ces_requests.post(
            url=url,
            headers=headers,
            json=payload
        )

        response.raise_for_status()
        result = response.json()

        case_number = result.get("id")

        # store in session for later use
        context.state["salesforce_case_number"] = case_number

        return {
            "success": True,
            "case_number": case_number,
            "message": "Salesforce case created successfully."
        }

    except Exception as e:
        context.state["salesforce_case_error"] = str(e)
        return {
            "success": False,
            "message": f"Failed to create Salesforce case: {str(e)}"
        }