def request_rewards() -> str:
    return "Your rewards request query has been received successfully."
