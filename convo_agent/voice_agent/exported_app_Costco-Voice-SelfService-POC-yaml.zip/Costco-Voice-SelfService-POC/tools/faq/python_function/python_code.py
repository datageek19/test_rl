def faq() -> str:
    return "Your FAQ query has been received successfully."
