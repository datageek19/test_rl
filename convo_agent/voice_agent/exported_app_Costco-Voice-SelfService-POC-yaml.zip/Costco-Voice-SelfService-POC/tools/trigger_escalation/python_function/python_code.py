from typing import Dict, Any

def trigger_escalation(summary: str, user_id: str, order_id: str, escalation_reason: str, member_tier: str, QueueID: str) -> Dict[str, Any]:
    """
    Triggers the human agent handoff by updating the TELEPHONY_PAYLOAD.
    
    Args:
        summary: A quick summary of the user's request for the agent.
        menu_id: The target Menu ID (defaults to 123 if not provided).
        
    Returns:
        The updated TELEPHONY_PAYLOAD dictionary.
    """
    
    payload = {
        "ujet": {
            "menu_id": QueueID,
            "type": "action",
            "action": "escalation",
            "escalation_reason": "by_virtual_agent",
            "session_variable": {
                "capture_target": "payload",
                "capture_type": ["field", "agent"],
                "payload": {
                    "user_id": user_id,
                    "order_id": order_id,
                    "member_tier": member_tier,
                    "summary": summary,
                    "escalation_reason": escalation_reason,
                    "main_topic": "General Escalation"
                }
            }
        }
    }

    
    context.state["TELEPHONY_PAYLOAD"] = payload

    return context.state["TELEPHONY_PAYLOAD"]