def get_order_history() -> dict:
    """
    Retrieves all orders for the validated member, including item details,
    fulfillment statuses, and tracking information.

    Reads membership_id from session state and passes it to the OMS
    as a query parameter, which handles the membership join server-side.

    Returns:
        dict: {
            "orders": [
                {
                    "order_id": int,
                    "source_order_number": str,
                    "status": str,
                    "ordered_date": str,
                    "items": [
                        {
                            "description": str,
                            "item_number": str,
                            "fulfillment_status": str or None,
                            "tracking_number": str or None,
                            "carrier": str or None
                        }
                    ]
                }
            ]
        }
    """
    membership_id = context.state.get("membership_id")

    if not membership_id:
        return {"orders": []}

    url = "http://104.131.40.195:3000/custom/oms/orders"

    try:
        res = ces_requests.get(url=url, params={"membershipId": membership_id})
        res.raise_for_status()
        member_orders = res.json()
    except Exception as e:
        context.state["debug_error"] = "API error: " + str(e)
        return {"orders": []}

    if not member_orders or not isinstance(member_orders, list):
        return {"orders": []}

    result = []
    for order in member_orders:
        try:
            line_items = order.get("lineItems") or []
            fulfillments = order.get("fulfillments") or []
            shipments = order.get("shipments") or []

            fulfillment_map = {f.get("item_number"): f.get("item_status") for f in fulfillments}
            tracking_map = {}
            carrier_map = {}
            delivered_date_map = {}
            for s in shipments:
                item_num = s.get("item_number")
                if item_num and item_num not in tracking_map:
                    tracking_map[item_num] = s.get("tracking_number")
                    carrier_map[item_num] = s.get("carrier_name")
                    delivered_date_map[item_num] = s.get("delivered_date")

            items = []
            for li in line_items:
                item_number = li.get("item_number")
                items.append({
                    "description": li.get("source_item_description"),
                    "item_number": item_number,
                    "fulfillment_status": fulfillment_map.get(item_number),
                    "tracking_number": tracking_map.get(item_number),
                    "carrier": carrier_map.get(item_number),
                    "delivered_date": delivered_date_map.get(item_number),
                })

            result.append({
                "order_id": order.get("id"),
                "source_order_number": order.get("source_order_number"),
                "status": order.get("status"),
                "ordered_date": order.get("ordered_date"),
                "items": items,
            })

        except Exception as e:
            context.state["debug_error"] = "Order processing error: " + str(e)
            continue

    return {"orders": result}
