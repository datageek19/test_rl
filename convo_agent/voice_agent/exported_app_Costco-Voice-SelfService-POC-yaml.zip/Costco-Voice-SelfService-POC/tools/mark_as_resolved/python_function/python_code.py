from typing import Dict, Any

def mark_as_resolved() -> Dict[str, Any]:
    """
    Explicitly locks the conversation state as 'Resolved' 
    so the Global Handler knows to send the 'end' signal.
    """
    # This forces the session parameter to update in the backend
    context.state["conversation_resolved"] = True
    
    return {"status": "STATE_LOCKED_RESOLVED"}