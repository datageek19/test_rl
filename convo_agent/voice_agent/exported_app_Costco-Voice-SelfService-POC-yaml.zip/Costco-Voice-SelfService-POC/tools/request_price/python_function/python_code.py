def request_price() -> str:
    return "Your price adjustment query has been received successfully."
