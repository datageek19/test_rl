def renew_membership() -> str:
    return "Your renewal query has been received successfully."
