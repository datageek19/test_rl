import re

def extract_area_code_language(phone_number: str) -> dict:
    """
    Extracts the area code from a given phone number and determines the default language.

    Purpose:
    --------
    This function normalizes a phone number, extracts its area code, and maps it
    to a default language preference for routing purposes.

    Input:
    ------
    phone_number (str):
        The caller's phone number. Can include formatting characters
        such as spaces, dashes, parentheses, or country codes.

    Processing Steps:
    -----------------
    1. Validate that the phone number is provided.
    2. Remove all non-digit characters.
    3. Normalize to the last 10 digits (standard US format).
    4. Extract the first 3 digits as the area code.
    5. Map the area code to a language:
        - "787" or "939" → Spanish ("es")
        - All others       → English ("en")

    Output:
    -------
    dict:
        {
            "status": "success" | "error",
            "area_code": "<3-digit code>",   # only if success
            "language": "en" | "es",         # only if success
            "message": "<error message>"     # only if error
        }

    Notes:
    ------
    - Phone numbers shorter than 10 digits after normalization are considered invalid.
    - Sensitive data is not exposed; masking is used only for internal logging if needed.
    - Designed for use in GECX Python tool (no external dependencies like Flask).
    """

    try:
        # Step 1: Validate input
        if not phone_number:
            return {
                "status": "error",
                "message": "Missing phone_number parameter"
            }

        # Step 2: Mask phone number (for safe logging/debugging)
        masked_phone = "*******" + phone_number[-4:] if len(phone_number) >= 4 else "****"

        # Step 3: Remove all non-digit characters
        digits_only = re.sub(r"\D", "", str(phone_number))

        # Step 4: Normalize to last 10 digits (standard US number format)
        normalized_number = digits_only[-10:] if len(digits_only) >= 10 else digits_only

        # Step 5: Validate normalized number length
        if len(normalized_number) != 10:
            return {
                "status": "error",
                "message": "Invalid phone number. Unable to derive a valid 10-digit number."
            }

        # Step 6: Extract area code (first 3 digits)
        area_code = normalized_number[:3]

        # Step 7: Map area code to language
        if area_code in ["787", "939", "870"]:
            language = "es"  # Spanish (Puerto Rico)
        else:
            language = "en"  # Default English

        # Step 8: Return success response
        return {
            "status": "success",
            "area_code": area_code,
            "language": language
        }

    except Exception as e:
        # Step 9: Handle unexpected errors safely
        return {
            "status": "error",
            "message": str(e)
        }