def modify_order() -> str:
    return "Your modify cancel query has been received successfully."
