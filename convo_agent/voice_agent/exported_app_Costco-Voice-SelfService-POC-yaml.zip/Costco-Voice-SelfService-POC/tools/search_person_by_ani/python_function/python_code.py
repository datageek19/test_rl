def search_person_by_ani(ani_code: str) -> dict:
    """
    Calls GMP search person API using ani_code and returns structured response.
    """
    #null checks
    if not ani_code or not str(ani_code).strip():
        return {
            "success": False,
            "message": "Invalid ANI code provided.",
            "person": None
        }

    url = "http://104.131.40.195:3000/gmp/searchperson"

    payload = {
        "searchText": str(ani_code),
        "limit": 20,
        "offset": 0
    }

    # make callout
    try:
        res = ces_requests.post(url=url, json=payload)
        res.raise_for_status()
        data = res.json()
    except:
        return {
            "success": False,
            "message": "Unable to fetch customer details at this time.",
            "person": None
        }

    # response check
    if not data or data.get("totalCount", 0) == 0:
        return {
            "success": False,
            "message": "No customer found for given ANI.",
            "person": None
        }

    results = data.get("results") or []
    if not results:
        return {
            "success": False,
            "message": "No matching records found.",
            "person": None
        }

    # Take first match
    person = results[0]

    # ✅ Safe extraction
    person_id = person.get("personId")
    first_name = person.get("firstName")
    last_name = person.get("lastName")

    phones = person.get("phones") or []
    phone = phones[0].get("number") if phones and phones[0] else None

    emails = person.get("emails") or []
    email = emails[0].get("address") if emails and emails[0] else None

    membership_card = person.get("singleActiveMembershipCardNumber")

    # ✅ Final response
    return person