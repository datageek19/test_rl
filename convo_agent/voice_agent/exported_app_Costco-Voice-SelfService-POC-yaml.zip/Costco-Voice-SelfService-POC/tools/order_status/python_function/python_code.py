def order_status(order_number: str) -> dict:
    """
    Retrieves the status and details of a specific order for the validated member.

    Args:
        order_number: The order_id (integer ID) of the order.

    Returns:
        dict: {
            "orders": [
                {
                    "order_id": int,
                    "source_order_number": str,
                    "status": str,
                    "ordered_date": str,
                    "items": [
                        {
                            "description": str,
                            "item_number": str,
                            "fulfillment_status": str or None,
                            "tracking_number": str or None,
                            "carrier": str or None
                        }
                    ],
                    "shipments": [
                        {
                            "tracking_number": str,
                            "carrier": str,
                            "items": list[str]
                        }
                    ]
                }
            ]
        }
    """
    if not order_number:
        return {"orders": []}

    url = f"http://104.131.40.195:3000/custom/oms/orders/{order_number}"

    try:
        res = ces_requests.get(url=url)
        res.raise_for_status()
        order = res.json()
    except:
        return {"orders": []}

    line_items = order.get("lineItems") or []
    fulfillments = order.get("fulfillments") or []
    shipments = order.get("shipments") or []

    fulfillment_map = {f.get("item_number"): f.get("item_status") for f in fulfillments}
    tracking_map = {}
    carrier_map = {}
    for s in shipments:
        item_num = s.get("item_number")
        if item_num and item_num not in tracking_map:
            tracking_map[item_num] = s.get("tracking_number")
            carrier_map[item_num] = s.get("carrier_name")

    desc_map = {li.get("item_number"): li.get("source_item_description") for li in line_items}

    items = []
    for li in line_items:
        item_number = li.get("item_number")
        items.append({
            "description": li.get("source_item_description"),
            "item_number": item_number,
            "fulfillment_status": fulfillment_map.get(item_number),
            "tracking_number": tracking_map.get(item_number),
            "carrier": carrier_map.get(item_number),
        })

    shipment_groups = {}
    for s in shipments:
        tracking = s.get("tracking_number")
        item_num = s.get("item_number")
        if tracking:
            if tracking not in shipment_groups:
                shipment_groups[tracking] = {
                    "tracking_number": tracking,
                    "carrier": s.get("carrier_name"),
                    "items": [],
                }
            if item_num and desc_map.get(item_num):
                shipment_groups[tracking]["items"].append(desc_map[item_num])

    result = [{
        "order_id": order.get("id"),
        "source_order_number": order.get("source_order_number"),
        "status": order.get("status"),
        "ordered_date": order.get("ordered_date"),
        "items": items,
        "shipments": list(shipment_groups.values()),
    }]

    return {"orders": result}
