def search_person_ani_direct_single(ani: str) -> dict:
    """
    Searches for a Costco member by ANI (phone number), intended for the
    steering agent's initial lookup. Only considers the result valid if the
    API returns a single direct match (isDirectMatch=true).

    On success, writes membership_id and customer_details to session.
    On failure, membership_id is set to None — callers should treat
    the absence of membership_id as the member being unvalidated.

    Args:
        ani: The caller's phone number from session metadata.

    Returns:
        dict: {
            "membership_id": str or None,
            "person_id": str or None,
            "first_name": str or None,
            "last_name": str or None,
            "phone": str or None,
            "email": str or None,
            "active_membership_count": int,
            "inactive_membership_count": int,
        }
    """
    _empty = {
        "membership_id": None,
        "person_id": None,
        "first_name": None,
        "last_name": None,
        "phone": None,
        "email": None,
        "active_membership_count": 0,
        "inactive_membership_count": 0,
    }

    # bypass this whole function.
    if not ani or not str(ani).strip():
        context.state["membership_id"] = None
        return _empty

    url = "http://104.131.40.195:3000/gmp/searchperson"

    try:
        res = ces_requests.post(url=url, json={"searchText": str(ani), "limit": 20, "offset": 0})
        res.raise_for_status()
        data = res.json()
    except:
        context.state["membership_id"] = None
        return _empty

    is_direct_match = data.get("isDirectMatch", False)
    results = data.get("results") or []

    if not is_direct_match or not results:
        context.state["membership_id"] = None
        return _empty

    person = results[0]

    person_id = person.get("personId")
    first_name = person.get("firstName")
    last_name = person.get("lastName")
    membership_id = person.get("singleActiveMembershipCardNumber")

    phones = person.get("phones") or []
    phone = phones[0].get("number") if phones else None

    emails = person.get("emails") or []
    email = emails[0].get("address") if emails else None

    active_membership_count = person.get("activeMembershipCount", 0)
    inactive_membership_count = person.get("inActiveMembershipCount", 0)

    context.state["membership_id"] = membership_id
    context.state["customer_details"] = {
        "person_id": person_id,
        "first_name": first_name,
        "last_name": last_name,
        "phone": phone,
        "email": email,
        "active_membership_count": active_membership_count,
        "inactive_membership_count": inactive_membership_count,
    }

    return {
        "membership_id": membership_id,
        "person_id": person_id,
        "first_name": first_name,
        "last_name": last_name,
        "phone": phone,
        "email": email,
        "active_membership_count": active_membership_count,
        "inactive_membership_count": inactive_membership_count,
    }
