from typing import Dict, Any

def route_to_order_queue() -> Dict[str, Any]:
    """
    Updates the session state QueueID to '60' 
    to trigger specific routing in the CCAI platform.
    """
    context.state["QueueID"] = "60"
    
    return {
        "status": "QUEUE_UPDATED"
    }