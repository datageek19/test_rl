from typing import Dict, Any

def enable_drop_protection(ani: str, menu_id: str) -> Dict[str, Any]:
    """
    Tells the CCaaS gateway to trigger a callback if this 
    session terminates unexpectedly (without a 'finish' signal).
    """
    payload = {
        "ujet": {
            "type": "action",
            "action": "update_custom_data",
            "custom_data": {
                "callback_on_disconnect": "true",
                "recovery_number": ani,
                "recovery_menu_id": str(menu_id),
                "disconnect_policy": "automatic_callback"
            }
        }
    }
    context.state["TELEPHONY_PAYLOAD"] = payload
    return {"status": "DROP_PROTECTION_ACTIVE"}