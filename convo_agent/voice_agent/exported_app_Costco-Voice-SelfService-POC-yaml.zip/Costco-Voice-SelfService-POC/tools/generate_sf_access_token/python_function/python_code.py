def generate_sf_access_token() -> str:
    """
    Generates Salesforce access token using Client Credentials flow
    and stores it in context.state["salesforce_access_token"]
    """
    url = "https://accenture51--retaildev2.sandbox.my.salesforce.com/services/oauth2/token"

    payload = {
        "grant_type": "client_credentials",
        "client_id": "3MVG9HbBKF.OyqUfyN2jBqofJlBl3PDAFJn5KxWVdTZByPqzQ8Ixb6.1PhDn9Dc4Kg5yjdmK.i0WOO7r.lywL",
        "client_secret": "A4B26B3D78270B52CFAE67E57406F423331EA929DF1328CB591F39AFE64A697C"
    }

    try:
        res = ces_requests.post(url=url, data=payload)
        res.raise_for_status()
        token_response = res.json()

        access_token = token_response.get("access_token")

        if not access_token:
            context.state["sf_auth_error"] = "No access token in response"
            return {"success": False}

        #  Store token in CX session
        context.state["salesforce_access_token"] = access_token

        return {
            "success": True,
            "access_token": access_token  # optional, remove in prod
        }

    except Exception as e:
        context.state["sf_auth_error"] = str(e)
        return {"success": False}
    
