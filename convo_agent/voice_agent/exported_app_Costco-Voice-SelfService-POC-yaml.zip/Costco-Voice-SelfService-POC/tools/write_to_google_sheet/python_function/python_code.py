def write_to_google_sheet(origin: str, subject: str) -> dict:
    """
    Writes Origin + Subject into Google Sheet
    """

    url = "https://script.google.com/macros/s/AKfycbx_rn8zoH-RRZNWWRZUYuN9RyrXOoaeTG-DV8RviejWVCL23QdbWKMAmAAvZIEMBXVSMA/exec"

    body = {
        "origin": origin,
        "subject": subject
    }

    try:
        res = ces_requests.post(url=url, json=body)
        res.raise_for_status()

        result = res.json()

        return {
            "success": result.get("success", False)
        }

    except Exception as e:
        context.state["sheet_error"] = str(e)
        return {"error": str(e)}