from typing import Dict, Any

def set_queue_id(passed_id: int) -> Dict[str, Any]:
    """
    Maps a simple input ID (1-5) to specific internal CCAI Queue IDs 
    and updates the conversation state.
    """
    # Define your mapping table
    queue_map = {
        1: 59,
        2: 60,
        3: 24,
        4: 24,
        5: 33,
    }
    
    # Get the internal ID, default to 0 (or a generic queue) if not found
    target_queue = queue_map.get(passed_id, 0)
    
    if target_queue != 0:
        # Update the CCAI context state
        context.state["QueueID"] = target_queue
        return {
            "status": "SUCCESS", 
            "mapped_queue": target_queue,
            "message": f"Queue set to {target_queue}"
        }
    else:
        return {
            "status": "ERROR", 
            "message": "Invalid input ID provided"
        }