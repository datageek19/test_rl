from typing import Dict, Any

def update_session_data(payload: Dict[str, Any]) -> Dict[str, Any]:
    """
    In the new Studio, 'payload' is often the full session object.
    This code 'hunts' for the holidays and bulletins keys.
    """
    # 1. Look for the data in common locations within the session object
    # Check 1: Direct keys (Common in the new Studio)
    # Check 2: Nested under 'parameters'
    # Check 3: Nested under 'session_info'
    
    holidays = payload.get("holidays") or \
               payload.get("parameters", {}).get("holidays") or \
               payload.get("session_info", {}).get("parameters", {}).get("holidays", [])
               
    bulletins = payload.get("bulletins") or \
                payload.get("parameters", {}).get("bulletins") or \
                payload.get("session_info", {}).get("parameters", {}).get("bulletins", [])

    # 2. FORCE the update to the state
    # This makes them 'Sticky' session parameters
    context.state["holidays"] = holidays
    context.state["bulletins"] = bulletins
    context.state["holiday_count"] = len(holidays)
    context.state["bulletin_count"] = len(bulletins)

    return {
        "status": "INJECTED",
        "message": f"Session updated with {len(holidays)} holidays and {len(bulletins)} bulletins.",
        "found": {
            "h": len(holidays),
            "b": len(bulletins)
        },
        # This will show you exactly what keys the function 'sees'
        "visible_keys": list(payload.keys()) 
    }