def upgrade_membership() -> str:
    return "Your upgrade query has been received successfully."
