from typing import Dict, Any

def absolute_hangup(summary: str, menu_id: str = "123") -> Dict[str, Any]:
    """
    Sends a final signal to UJET to hang up the call and log the resolution.
    """
    payload = {
          "ujet": {
              "menu_id": "44",
              "type": "action",
              "action": "end",
              "escalation_reason": "by_virtual_agent",
              "session_variable": {
                  "capture_target": "payload",
                  "capture_type": ["field", "agent"],
                  "payload": {
                      "summary": summary,
                  }
              }
          }
      }

    # 2. The State Update (The 'Sticky' instruction)
    context.state["TELEPHONY_PAYLOAD"] = payload
    
    # 3. The Signal to the Agent
    #return {"control": "TERMINATE_PSTN_NOW"}
    return context.state["TELEPHONY_PAYLOAD"] 