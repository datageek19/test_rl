def cancel_order(order_number: str) -> dict:
    """
    Attempts to cancel the order identified by order_number.

    Eligibility rules:
    - Order status must be 'Pending'

    Args:
        order_number: The source_order_number of the order to cancel.

    Reads membership_id from session state.

    Returns:
        dict: {
            "cancelled": bool,
            "reason": str,
            "order_summary": {
                "source_order_number": str,
                "items": list[str]
            } or None
        }
    """
    current_order_number = order_number
    membership_id = context.state.get("membership_id")

    if not current_order_number or not membership_id:
        return {"cancelled": False, "reason": "Missing order number or member ID.", "order_summary": None}

    url = "http://104.131.40.195:3000/custom/oms/orders"

    try:
        res = ces_requests.get(url=url, params={"membershipId": membership_id})
        res.raise_for_status()
        member_orders = res.json()
    except:
        return {"cancelled": False, "reason": "Unable to retrieve order information at this time.", "order_summary": None}

    order = next(
        (o for o in member_orders
         if o.get("source_order_number") == str(current_order_number)),
        None
    )

    if not order:
        return {"cancelled": False, "reason": "Order not found for this member.", "order_summary": None}

    line_items = order.get("lineItems") or []
    item_descriptions = [li.get("source_item_description", "") for li in line_items]
    order_summary = {
        "source_order_number": order.get("source_order_number"),
        "items": item_descriptions,
    }

    if order.get("status") != "Pending":
        return {
            "cancelled": False,
            "reason": f"Order cannot be cancelled — it is currently being processed or has shipped (status: {order.get('status')}).",
            "order_summary": order_summary,
        }

    try:
        order_id = order.get("id")
        update_url = f"http://104.131.40.195:3000/custom/oms/orders/{order_id}"
        update_body = {
            "sourceOrderNumber": order.get("source_order_number"),
            "status": "Cancelled",
            "billToFirstName": order.get("bill_to_first_name"),
            "billToLastName": order.get("bill_to_last_name"),
            "billToEmail": order.get("bill_to_email"),
            "billToDayPhone": order.get("bill_to_day_phone"),
            "billToContactPhone": order.get("bill_to_contact_phone"),
            "billToCompanyName": order.get("bill_to_company_name"),
            "billToLine1": order.get("bill_to_line1"),
            "billToLine2": order.get("bill_to_line2"),
            "billToCity": order.get("bill_to_city"),
            "billToState": order.get("bill_to_state"),
            "billToPostalCode": order.get("bill_to_postal_code"),
            "orderedDate": order.get("ordered_date"),
            "completedDate": order.get("completed_date"),
            "languagePreference": order.get("language_preference"),
            "warehouseNumber": order.get("warehouse_number"),
            "membershipNumber": order.get("membership_number"),
        }
        update_res = ces_requests.put(url=update_url, json=update_body)
        update_res.raise_for_status()
    except:
        return {"cancelled": False, "reason": "Unable to process the cancellation at this time. Please try again.", "order_summary": order_summary}

    return {
        "cancelled": True,
        "reason": "Order successfully cancelled.",
        "order_summary": order_summary,
    }
