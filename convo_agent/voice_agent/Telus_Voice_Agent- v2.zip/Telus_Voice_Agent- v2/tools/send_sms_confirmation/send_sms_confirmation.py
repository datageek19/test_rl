"""
send_sms_confirmation — Telus Voice Agent demo tool.

Sends a short confirmation SMS to the customer containing their Telus support
case number. For the demo this is a stub: it logs the request and returns a
mock message id. Swap the body of `send_sms_confirmation` for a real Twilio
(or equivalent) client call when wiring up to a live environment.
"""

from __future__ import annotations

import logging
import re
import uuid
from typing import Optional

logger = logging.getLogger(__name__)

_E164 = re.compile(r"^\+[1-9]\d{7,14}$")


def send_sms_confirmation(
    phone_number: str,
    case_number: str,
    first_name: Optional[str] = None,
) -> dict:
    if not _E164.match(phone_number or ""):
        return {
            "status": "error",
            "reason": "invalid_phone_number",
            "message": "phone_number must be in E.164 format, e.g. +14165551234.",
        }
    if not case_number:
        return {"status": "error", "reason": "missing_case_number"}

    greeting = f"Hi {first_name}, " if first_name else "Hi, "
    body = (
        f"{greeting}this is Telus. Your support case {case_number} has been "
        f"created. A specialist will follow up shortly. Reply STOP to opt out."
    )

    message_id = f"demo-{uuid.uuid4().hex[:12]}"
    logger.info("SMS queued: to=%s case=%s id=%s", phone_number, case_number, message_id)

    return {
        "status": "sent",
        "message_id": message_id,
        "to": phone_number,
        "body": body,
    }
