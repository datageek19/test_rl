# Telus Voice Agent — Evals

Three smoke scenarios covering the home-internet troubleshooting agent.

## Layout

```
evals/
├── README.md
├── eval_set.json                    # index
├── happy_path_reboot.eval.json      # no outage → power cycle → resolved
├── active_outage.eval.json          # active outage → notify + SMS + end
└── out_of_scope_billing.eval.json   # billing question → decline + escalate
```

## Scenario format

- `metadata`   — name, description, tags
- `fixtures`   — canned tool responses injected when the agent calls a tool
- `turns`      — scripted user/agent turns with expected intent / tool calls
- `assertions` — overall checks (required tool-call order, forbidden phrases, forbidden behaviors)

Assert on intent and tool-call order, not exact wording — the agent paraphrases.

## Running

Point your eval runner (Agent Studio console, Vertex AI eval API, or a pytest
harness) at this folder. Use a sandbox Salesforce connection for any live run.
