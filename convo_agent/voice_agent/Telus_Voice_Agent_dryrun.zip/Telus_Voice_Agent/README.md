# Telus Voice Agent (Gemini Enterprise CX Agent Studio / ADK)

A minimal, demo-ready voice agent that helps Telus residential customers
troubleshoot a single, realistic, high-frequency issue:

> **Home Internet Not Working**

Built for Google Cloud's **Gemini Enterprise Customer Engagement Suite (CX Agent Studio)** using Gemini 2.5 Flash.

## Scope

- **In scope**: One use case only — home internet outage / "no connection" /
  modem light issues. The agent walks the customer through identification,
  outage check, a basic power-cycle troubleshooting flow, and escalation.
- **Out of scope**: Billing, mobile service, Optik TV, sales, account changes.
  These are politely declined and transferred.

## Repo layout

```
Telus_Voice_Agent/
├── app.json                                # App config, variables, voice, guardrails
├── agents/
│   └── root_agent/
│       ├── root_agent.json                 # Model + tool/toolset wiring
│       └── instruction.txt                 # Agent prompt / conversation flow
├── guardrails/
│   ├── Safety_Guardrail_1765971497313/     # Harm-category safety thresholds
│   └── Prompt_Guardrail_1765971497313/     # LLM prompt-injection protection
├── tools/                                  # Python-code tools (CES runtime)
│   ├── execute_salesforce_query/           # SOQL reader (customer, outage)
│   ├── create_salesforce_case/             # Case creation (escalation)
│   └── send_twilio_sms/                    # SMS (case #/status link)
├── toolsets/                               # Connector-backed actions
│   ├── get_customer_details/               # Salesforce SOQL connector
│   └── create_case/                        # Salesforce Case create connector
└── sample_data/                            # Minimal synthetic data for demo
    ├── customers.json
    └── outages.json
```

## Tools used (and when)

| Tool                                   | When the agent uses it                                      |
| -------------------------------------- | ----------------------------------------------------------- |
| `get_customer_details_ExecuteCustomQuery` | (1) Silent lookup on call start, (2) optional outage check |
| `create_case_create_Case`              | Only for escalation or a resolved-case reference            |
| `send_twilio_sms`                      | Only after a case is created, to text the case number       |
| `end_session`                          | Always the last action                                      |

Irrelevant Costco tools (`execute_bigquery_update`, `update_address`,
`update_member`) were removed.

## Conversation flow

1. **Silent init** — SOQL lookup by caller phone number (last 4 digits).
2. **Greet + verify** identity.
3. **Confirm issue** is home-internet related (else escalate).
4. **Outage check** via SOQL on `TelusOutage__dll`.
5. **Guided troubleshooting** — modem lights → power cycle → verify.
6. **Case creation + SMS** if unresolved / outage confirmed.
7. **Close** or **escalate** to human.

## Guardrails

- Built-in Safety Guardrail (harm categories) + Prompt Guardrail enabled.
- Instruction-level rules: no fabricated data, no invented capabilities,
  no remote "fixes" the agent didn't actually perform, single-issue scope,
  escalate on any live-agent request.

## Running the demo

1. Import this folder into **Agent Studio** (Gemini Enterprise → CES).
2. Configure the Salesforce + Twilio connections used in `toolsets/*.json`
   and the credentials in `tools/*/python_function/python_code.py` (env vars
   `SALESFORCE_*`, `TWILIO_*`). For a no-backend dry run, see **Synthetic data** below.
3. Start a test call. The agent immediately calls `get_customer_details`
   before speaking, so make sure at least one sample record matches the
   caller-ID phone number pattern in `instruction.txt` (default: `%9549%`).

## Synthetic data

Minimal records under `sample_data/` mirror the SOQL fields the agent expects.
Load them into your Salesforce sandbox (or a stub connector) to exercise
the full flow end-to-end.

- `TelusCustomer__dll` — one customer whose phone ends in `9549`.
- `TelusOutage__dll` — one "no outage" row so Step 4 proceeds to troubleshooting.

Swap the `outage_status__c` to `"active"` to test the outage branch.
