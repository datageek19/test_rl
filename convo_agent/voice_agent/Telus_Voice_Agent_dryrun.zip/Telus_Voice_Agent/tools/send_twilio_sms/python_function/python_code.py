from typing import Optional


def send_twilio_sms(
    to_number: str,
    message_body: str,
) -> Optional[dict]:
    """
    Sends an SMS message to a Telus customer using the Twilio API with Basic Authentication.

    Args:
        to_number: The destination phone number (E.164 format, e.g., +15551234567).
        message_body: The SMS body text (e.g., case number + service status link).

    Returns:
        A dict containing success status and Twilio message SID on success,
        or error details on failure.

    Notes:
        This function uses `ces_requests`, which works similarly to the `requests`
        library. Twilio requires Basic Auth where the username is the Account SID
        and the password is the Auth Token.
        For the demo, credentials are placeholders; in production, read from env.
    """
    import base64
    import os

    account_sid = os.getenv('TWILIO_ACCOUNT_SID', 'test')
    auth_token = os.getenv('TWILIO_AUTH_TOKEN', 'test')
    from_number = os.getenv('TWILIO_FROM_NUMBER', '+12029309922')

    userpass = f"{account_sid}:{auth_token}".encode("utf-8")
    basic_auth_header = base64.b64encode(userpass).decode("utf-8")

    headers = {
        "Authorization": f"Basic {basic_auth_header}",
        "Content-Type": "application/x-www-form-urlencoded",
    }

    url = f"https://api.twilio.com/2010-04-01/Accounts/{account_sid}/Messages.json"

    data = {
        "From": from_number,
        "To": to_number,
        "Body": message_body,
    }

    try:
        res = ces_requests.request(
            method=HttpMethod.POST,
            url=url,
            data=data,
            headers=headers,
        )

        try:
            res.raise_for_status()
        except Exception:
            try:
                err_json = res.json()
                return {
                    "success": False,
                    "status_code": res.status_code,
                    "error": err_json.get("message"),
                    "twilio_code": err_json.get("code"),
                    "raw": err_json,
                }
            except:
                return {
                    "success": False,
                    "status_code": res.status_code,
                    "error": res.text,
                }

        msg = res.json()
        return {
            "success": True,
            "sid": msg.get("sid"),
            "raw": msg,
        }

    except Exception as e:
        return {
            "success": False,
            "error": str(e),
            "status_code": None,
        }
