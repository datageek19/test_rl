# Telus Voice Agent — Evals

Two smoke scenarios for the home-internet troubleshooting agent.

## Layout

```
evals/
├── README.md
├── eval_set.json                    # index
├── happy_path_reboot.eval.json      # no internet → power cycle → resolved
└── out_of_scope_billing.eval.json   # billing question → decline + escalate
```

## Scenario format

- `metadata`   — name, description, tags
- `fixtures`   — canned tool responses injected when the agent calls a tool
- `turns`      — scripted user/agent turns with expected intent / tool calls
- `assertions` — overall checks (required tool-call order, forbidden phrases)

Assert on intent and tool-call order, not exact wording — the agent paraphrases.

## Running

Point your eval runner (Agent Studio console, Vertex AI eval API, or a pytest
harness) at this folder. Use a sandbox Salesforce connection for any live run.
