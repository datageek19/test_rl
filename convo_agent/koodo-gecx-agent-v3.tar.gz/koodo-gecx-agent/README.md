# Koodo Mobile Conversational Agent

ADK-native customer support agent for Koodo Mobile, deployable to Cloud Run
or CX Agent Studio (GECX).

## Architecture

```
LOCAL DEV (Gemini CLI / adk)         PRODUCTION (GECX)
─────────────────────────            ──────────────────────
                                     
  koodo_agent/                       CX Agent Studio
  ├── agent.py    ← root_agent      ├── Agent instructions (natural language)
  ├── tools.py    ← FunctionTools   ├── OpenAPI tools (8 specs)
  └── __init__.py                    ├── Guardrails (5 rules)
        │                            └── Web widget / Telephony
        │ adk run / adk web                   │
        ▼                                     ▼
  Gemini 2.5 Flash                   Cloud Run Webhook
  (direct tool calls)                (Flask REST API)
```

**Two deployment paths, same agent logic:**

| Path | When to use | Tools mechanism |
|------|------------|-----------------|
| `adk run` / `adk web` | Local dev, testing with Gemini CLI | Python FunctionTools (tools.py) |
| CX Agent Studio | Production, web widget, telephony | OpenAPI tools → Cloud Run webhook |

## Quick Start (Local with Gemini CLI)

```bash
# 1. Install ADK
pip install google-adk

# 2. Authenticate (pick one)
# Option A: Vertex AI (recommended)
gcloud auth application-default login
export GOOGLE_CLOUD_PROJECT=your-project-id
export GOOGLE_CLOUD_LOCATION=us-central1

# Option B: Google AI Studio (quick prototyping)
export GOOGLE_GENAI_API_KEY=your-api-key

# 3. Run the agent
adk run koodo_agent          # CLI mode
adk web koodo_agent          # Web UI at http://localhost:8000

# 4. Try it
# "What plans do you have?"
# "Show me the Samsung Galaxy A57"
# "Why did my bill go up?"
```

## Deploy to Cloud Run

```bash
# One-command deploy (ADK built-in)
adk deploy cloud_run koodo_agent \
  --project=$GOOGLE_CLOUD_PROJECT \
  --region=us-central1

# Or deploy the webhook separately for GECX
cd webhook
gcloud run deploy koodo-webhook --source . \
  --region us-central1 --allow-unauthenticated
```

## Connect to CX Agent Studio

Once the webhook is deployed to Cloud Run:

1. Open console.cloud.google.com → **Customer Engagement AI** → **CX Agent Studio**
2. Create a new agent application
3. Paste the agent instruction from `agent.py` (the KOODO_INSTRUCTION string)
4. For each OpenAPI spec in `koodo_agent/openapi/`:
   - Create Tool → OpenAPI → paste the spec
   - Set server URL to your Cloud Run webhook URL
5. Add guardrails (see `docs/requirements.md` section on guardrails)
6. Deploy via Web Widget or Telephony channel

## Design-Time Pipeline

The `design_pipeline` SequentialAgent generates conversation designs:

```bash
adk run koodo_agent --agent design_pipeline
# Then provide Koodo website context as input
```

Pipeline: **planner** → **extractor** → **designer**

Each agent writes to shared session state via `output_key`, and the next
agent reads it via `{variable_name}` template syntax in its instruction.

## Project Structure

```
koodo-gecx-agent/
├── koodo_agent/              # ADK agent package
│   ├── __init__.py           # Exports root_agent (mandatory)
│   ├── agent.py              # Agent definitions + SequentialAgent pipeline
│   ├── tools.py              # FunctionTools with mock data
│   └── openapi/              # OpenAPI specs for GECX deployment
│       └── get_plans.yaml    # (one per tool, register individually)
├── webhook/                  # Cloud Run backend for GECX
│   ├── main.py               # Flask REST API
│   ├── requirements.txt
│   └── Dockerfile
├── docs/
│   └── requirements.md       # Full PRD (Steps 1-3)
├── pyproject.toml            # Python dependencies
├── .env                      # ADK environment config
└── README.md
```

## Key Design Decisions

1. **FunctionTools for local, OpenAPI for GECX** — Same logic, two interfaces.
   Tools.py is the source of truth; the webhook mirrors it as HTTP endpoints.

2. **SequentialAgent for design pipeline** — Uses ADK's native `output_key` +
   session state for agent-to-agent data passing. Not a custom orchestrator.

3. **No invented config formats** — GECX doesn't have a single-file import.
   Agent setup is done via console, REST API, or MCP server. The OpenAPI
   specs and instruction text are the deployable artifacts.

4. **Mock data grounded in real Koodo pricing** — Galaxy A57 at $0/$15 Tab,
   80GB plan at $50 before autopay, perks system, $25 referral — all sourced
   from koodomobile.com as of April 2026.
