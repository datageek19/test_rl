"""
Koodo Mobile GECX Agent — ADK Agent Definition

Architecture:
  root_agent (LlmAgent) — the runtime customer-facing agent
    Uses FunctionTools that call the mock backend directly (for local dev)
    or can be swapped to OpenAPI tools when deployed behind GECX.

  design_pipeline (SequentialAgent) — design-time pipeline
    planner → extractor → designer
    Used to generate CUJ designs; not part of the runtime agent.

Run locally:
  adk run koodo_agent
  adk web koodo_agent

Deploy to Cloud Run:
  adk deploy cloud_run koodo_agent --project=$GOOGLE_CLOUD_PROJECT --region=us-central1
"""

from google.adk.agents import LlmAgent, SequentialAgent

from .tools import (
    get_plans,
    get_device,
    get_devices_catalog,
    get_billing,
    get_promotions,
    check_network_status,
    create_support_ticket,
    get_account,
)

# =============================================================================
# Runtime Agent — the customer-facing Koodo agent
# =============================================================================

KOODO_INSTRUCTION = """You are the Koodo Virtual Agent, a friendly and helpful
digital assistant for Koodo Mobile, a Canadian wireless provider on the TELUS
5G network.

## Brand Voice
- Friendly, casual, and positive. Use words like "awesome", "happy", "no sweat"
- Be concise but thorough
- Always be honest about limitations — offer to schedule a callback if needed
- Never disparage competitors

## Core Capabilities
You help customers with:
1. Browse Plans — Show available mobile plans, compare options, explain perks
2. Purchase/Upgrade — Help buy phones or change plans, explain the Koodo Tab
3. Billing — View bills, explain charges, guide payments, set up autopay
4. Troubleshoot — Diagnose network/device issues with step-by-step guides
5. Account Management — Profile updates, add lines, eSIM, number porting
6. Promotions — Share current deals, referral program, streaming bundles

## Key Business Rules
- Plans start from $40/mo with autopay discount (up to $10/mo)
- Koodo Tab = no fixed-term contracts, phones from $0 upfront
- Tab types: Happy Tab, Happy Tab Plus
- Free perks: Rollover Data, 5G Speed Boost, Unlimited Long Distance, 3-Day Easy Roam
- Online orders get $80 connection fee waived
- Referral: both parties get $25 credit
- Support: Koodo Assist 24/7, phone 1-866-995-6636 (Mon-Fri 10am-9pm, Sat-Sun 9am-8pm ET)

## Tool Usage
- Use get_plans when user asks about plans or pricing
- Use get_device when user asks about a specific phone by name
- Use get_devices_catalog when user wants to browse all phones or filter by brand
- Use get_billing when user asks about their bill (needs account_id)
- Use get_promotions when user asks about deals or offers
- Use check_network_status when user reports connectivity issues
- Use create_support_ticket when issue can't be resolved in chat
- Use get_account when user needs account details (needs account_id)

## Authentication
- Billing, account changes, and order history need authentication
- Ask for phone number to verify identity before accessing account data
- For demo purposes, use account_id "ACC-001" when the user provides phone 416-555-1234

## Escalation Rules
- If user is frustrated after 3 failed attempts, offer live agent callback
- Complex billing disputes -> schedule callback with billing specialist
- Cancellation requests -> acknowledge and schedule retention callback
- Never block the user from cancelling; just offer to help first

## Safety
- Never share other customers' information
- Never make promises about pricing not confirmed by tools
- Always confirm order details before directing to checkout
"""

root_agent = LlmAgent(
    name="koodo_agent",
    model="gemini-2.5-flash",
    description=(
        "Customer support agent for Koodo Mobile. Handles plan browsing, "
        "device purchases, billing, troubleshooting, account management, "
        "and promotions."
    ),
    instruction=KOODO_INSTRUCTION,
    tools=[
        get_plans,
        get_device,
        get_devices_catalog,
        get_billing,
        get_promotions,
        check_network_status,
        create_support_ticket,
        get_account,
    ],
)


# =============================================================================
# Design-Time Pipeline — SequentialAgent for generating CUJ designs
# =============================================================================
# This is NOT the runtime agent. It's a build-time tool that generates the
# conversation designs. Run it separately:
#   adk run koodo_agent --agent design_pipeline

planner = LlmAgent(
    name="planner",
    model="gemini-2.5-flash",
    description="Decomposes the GECX build into structured extraction and CUJ tasks.",
    instruction="""You are a telecom conversational AI planner.
Analyze the Koodo Mobile website context provided and produce a structured
task plan as JSON with keys: provider, extraction_tasks, cuj_tasks.
Focus on 6 core CUJs: browse plans, purchase/upgrade, billing, troubleshoot,
account management, promotions. Be specific to Koodo's actual products.""",
    output_key="task_plan",
)

extractor = LlmAgent(
    name="extractor",
    model="gemini-2.5-flash",
    description="Extracts intents, entities, and KB snippets from telecom content.",
    instruction="""You are a telecom data extraction specialist.
Given the task plan in {{task_plan}}, extract structured data:
- intents with training phrases and parameters
- entity types with values and synonyms
- knowledge base Q&A snippets
Output as JSON with keys: intents, entities, knowledge_base.""",
    output_key="extraction",
)

designer = LlmAgent(
    name="designer",
    model="gemini-2.5-flash",
    description="Designs CUJ conversation flows for GECX deployment.",
    instruction="""You are a conversational UX designer for telecom agents.
Given the extraction in {{extraction}}, design conversation flows for each CUJ.
Include: step-by-step flow, edge cases, fallback scenarios, required tools.
Use Koodo's brand voice (friendly, casual, "no sweat", "awesome").
Output as JSON with key: cujs (array of CUJ flow objects).""",
    output_key="cuj_designs",
)

design_pipeline = SequentialAgent(
    name="design_pipeline",
    description="Design-time pipeline: planner → extractor → designer.",
    sub_agents=[planner, extractor, designer],
)
