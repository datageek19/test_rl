"""Koodo Mobile Conversational Agent — ADK Package.

ADK expects `root_agent` to be importable from the agent package.
This is the entry point for `adk run`, `adk web`, and `adk deploy`.
"""

from .agent import root_agent
