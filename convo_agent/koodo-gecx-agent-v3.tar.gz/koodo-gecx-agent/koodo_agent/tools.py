"""
Koodo Mobile Agent Tools — ADK FunctionTools

These are Python functions that ADK auto-wraps as FunctionTools.
Each function's docstring becomes the tool description sent to the LLM.
Parameter type hints become the function declaration schema.

For GECX deployment, these would be replaced by OpenAPI tools pointing
at a Cloud Run backend. For local dev with `adk run`/`adk web`, these
work directly as mock backends.
"""

import uuid
from datetime import datetime, timedelta


# =============================================================================
# Mock Data (reflects real Koodo pricing as of April 2026)
# =============================================================================

_PLANS = [
    {
        "plan_id": "5g-20gb",
        "name": "5G 20GB Plan",
        "data_gb": 20,
        "monthly_price": 40.00,
        "autopay_discount": 10.00,
        "network_speed": "5G",
        "plan_type": "postpaid",
        "includes": [
            "Unlimited Canada-wide calling",
            "Unlimited international SMS",
            "1 free perk of your choice",
        ],
        "available_perks": [
            "Rollover Data",
            "5G Speed Boost",
            "Unlimited Long Distance",
            "3-Day Easy Roam",
        ],
    },
    {
        "plan_id": "5g-80gb",
        "name": "5G 80GB Plan",
        "data_gb": 80,
        "monthly_price": 50.00,
        "autopay_discount": 10.00,
        "network_speed": "5G",
        "plan_type": "postpaid",
        "includes": [
            "Unlimited Canada-wide calling",
            "Unlimited international SMS",
            "20GB bonus data included",
            "1 free perk of your choice",
        ],
        "available_perks": [
            "Rollover Data",
            "5G Speed Boost",
            "Unlimited Long Distance",
            "3-Day Easy Roam",
        ],
    },
    {
        "plan_id": "5g-80gb-roam",
        "name": "5G 80GB Canada/US/Mexico Plan",
        "data_gb": 80,
        "monthly_price": 60.00,
        "autopay_discount": 10.00,
        "network_speed": "5G",
        "plan_type": "postpaid",
        "includes": [
            "Unlimited Canada-wide calling",
            "Unlimited international SMS",
            "Canada/US/Mexico roaming included",
            "1 free perk of your choice",
        ],
        "available_perks": [
            "Rollover Data",
            "5G Speed Boost",
            "Unlimited Long Distance",
            "3-Day Easy Roam",
        ],
    },
    {
        "plan_id": "5g-100gb-roam",
        "name": "5G 100GB Canada/US/Mexico Plan",
        "data_gb": 100,
        "monthly_price": 75.00,
        "autopay_discount": 10.00,
        "network_speed": "5G",
        "plan_type": "postpaid",
        "includes": [
            "Unlimited Canada-wide calling",
            "Unlimited international SMS",
            "Canada/US/Mexico roaming included",
            "Hotspot included",
            "1 free perk of your choice",
        ],
        "available_perks": [
            "Rollover Data",
            "5G Speed Boost",
            "Unlimited Long Distance",
            "3-Day Easy Roam",
        ],
    },
    {
        "plan_id": "prepaid-4gb",
        "name": "Prepaid 4GB Plan",
        "data_gb": 4,
        "monthly_price": 25.00,
        "autopay_discount": 0,
        "network_speed": "4G LTE",
        "plan_type": "prepaid",
        "includes": [
            "Unlimited Canada-wide calling",
            "Unlimited international SMS",
            "Bonus 500MB/mo with auto top-up",
        ],
        "available_perks": [],
    },
]

_DEVICES = [
    {
        "device_id": "samsung-galaxy-a57",
        "name": "Samsung Galaxy A57",
        "brand": "Samsung",
        "upfront_cost": 0,
        "monthly_tab": 15.00,
        "tab_type": "Happy Tab",
        "condition": "new",
        "in_stock": True,
        "colors": ["Black", "Lilac", "Light Blue"],
    },
    {
        "device_id": "samsung-galaxy-a16",
        "name": "Samsung Galaxy A16",
        "brand": "Samsung",
        "upfront_cost": 0,
        "monthly_tab": 4.00,
        "tab_type": "Happy Tab",
        "condition": "new",
        "in_stock": True,
        "colors": ["Black", "Light Green"],
    },
    {
        "device_id": "samsung-galaxy-s24-cpo",
        "name": "Samsung Galaxy S24 (Certified Pre-Owned)",
        "brand": "Samsung",
        "upfront_cost": 0,
        "monthly_tab": 15.00,
        "tab_type": "Happy Tab",
        "condition": "certified_pre_owned",
        "in_stock": True,
        "colors": ["Amber Yellow", "Onyx Black"],
    },
    {
        "device_id": "google-pixel-10a",
        "name": "Google Pixel 10a",
        "brand": "Google",
        "upfront_cost": 0,
        "monthly_tab": 29.38,
        "tab_type": "Happy Tab",
        "condition": "new",
        "in_stock": True,
        "colors": ["Lavender", "Chalk", "Charcoal"],
    },
    {
        "device_id": "motorola-moto-g-2026",
        "name": "Motorola moto g - 2026",
        "brand": "Motorola",
        "upfront_cost": 0,
        "monthly_tab": 8.00,
        "tab_type": "Happy Tab",
        "condition": "new",
        "in_stock": True,
        "colors": ["Slipstream"],
    },
    {
        "device_id": "apple-iphone-air",
        "name": "Apple iPhone Air",
        "brand": "Apple",
        "upfront_cost": 0,
        "monthly_tab": 37.08,
        "tab_type": "Happy Tab Plus",
        "condition": "new",
        "in_stock": True,
        "colors": ["Sky Blue", "Starlight", "Midnight"],
    },
]

_PROMOTIONS = [
    {
        "promo_id": "online-connection-fee",
        "name": "Free Connection Online",
        "description": "Save $80 connection fee when you order online.",
        "discount_amount": 80.00,
        "conditions": "Online orders only. Sign up for Koodo email deals.",
        "promo_type": "connection_fee_waiver",
    },
    {
        "promo_id": "refer-friend-25",
        "name": "Refer a Friend",
        "description": "You and your friend each get $25 off your bill.",
        "discount_amount": 25.00,
        "conditions": "Friend must activate a new postpaid plan.",
        "promo_type": "referral",
    },
    {
        "promo_id": "stream-plus-bundle",
        "name": "Stream+ Bundle with Apple TV",
        "description": "Apple TV + Stream+ from $20/mo for first 3 months. Save $10/mo bundled.",
        "discount_amount": 10.00,
        "conditions": "Eligible plans only. Regular price after 3 months.",
        "promo_type": "streaming_bundle",
    },
    {
        "promo_id": "pick-your-perk",
        "name": "Pick Your Perk",
        "description": "Choose a free perk: Rollover Data, 5G Speed Boost, Long Distance, or Easy Roam.",
        "discount_amount": 0,
        "conditions": "Available on eligible postpaid plans $40+/mo.",
        "promo_type": "plan_feature",
    },
]

_MOCK_ACCOUNT = {
    "account_id": "ACC-001",
    "name": "Jane Doe",
    "phone_number": "416-555-1234",
    "plan": {
        "name": "5G 80GB Plan",
        "data_gb": 80,
        "monthly_price": 47.00,
        "selected_perk": "Rollover Data",
    },
    "tab_balance": 180.00,
    "lines": [
        {
            "phone_number": "416-555-1234",
            "plan_name": "5G 80GB Plan",
            "device": "Samsung Galaxy S24",
        }
    ],
}


# =============================================================================
# Tool Functions — ADK auto-wraps these as FunctionTool via type hints + docstrings
# =============================================================================


def get_plans(
    plan_type: str = "",
    min_data_gb: int = 0,
    max_price: float = 0,
) -> dict:
    """Get available Koodo mobile plans. Optionally filter by plan_type
    (postpaid, prepaid, byod), minimum data in GB, or max monthly price in CAD.

    Args:
        plan_type: Filter by type. Options: postpaid, prepaid, byod. Empty for all.
        min_data_gb: Minimum data amount in GB. 0 for no minimum.
        max_price: Maximum monthly price in CAD after autopay. 0 for no limit.

    Returns:
        Dictionary with 'plans' key containing list of matching plans.
    """
    filtered = _PLANS
    if plan_type:
        filtered = [p for p in filtered if p["plan_type"] == plan_type]
    if min_data_gb > 0:
        filtered = [p for p in filtered if p["data_gb"] >= min_data_gb]
    if max_price > 0:
        filtered = [
            p for p in filtered
            if (p["monthly_price"] - p["autopay_discount"]) <= max_price
        ]
    return {"plans": filtered}


def get_device(device_id: str) -> dict:
    """Get details for a specific Koodo device by its ID slug.

    Args:
        device_id: Device identifier slug, e.g. 'samsung-galaxy-a57', 'apple-iphone-air'.

    Returns:
        Device details including pricing, Tab info, colors, and stock status.
    """
    device = next((d for d in _DEVICES if d["device_id"] == device_id), None)
    if not device:
        return {"error": f"Device '{device_id}' not found. Try get_devices_catalog to see available devices."}
    return device


def get_devices_catalog(
    brand: str = "",
    condition: str = "",
    max_monthly: float = 0,
) -> dict:
    """List all available Koodo devices. Optionally filter by brand, condition, or max Tab cost.

    Args:
        brand: Filter by brand name (Apple, Samsung, Google, Motorola). Empty for all.
        condition: Filter by condition: 'new' or 'certified_pre_owned'. Empty for all.
        max_monthly: Maximum monthly Tab payment in CAD. 0 for no limit.

    Returns:
        Dictionary with 'devices' key containing list of matching devices.
    """
    filtered = _DEVICES
    if brand:
        filtered = [d for d in filtered if d["brand"].lower() == brand.lower()]
    if condition:
        filtered = [d for d in filtered if d["condition"] == condition]
    if max_monthly > 0:
        filtered = [d for d in filtered if d["monthly_tab"] <= max_monthly]
    return {
        "devices": [
            {
                "device_id": d["device_id"],
                "name": d["name"],
                "brand": d["brand"],
                "monthly_tab": d["monthly_tab"],
                "upfront_cost": d["upfront_cost"],
                "condition": d["condition"],
            }
            for d in filtered
        ]
    }


def get_billing(account_id: str) -> dict:
    """Get billing information for a Koodo account. Requires authentication.

    Args:
        account_id: The account ID, e.g. 'ACC-001'.

    Returns:
        Billing details including balance, due date, charges, and autopay status.
    """
    if account_id != "ACC-001":
        return {"error": "Account not found. For demo, use account_id 'ACC-001'."}

    acct = _MOCK_ACCOUNT
    due = (datetime.now() + timedelta(days=14)).strftime("%Y-%m-%d")
    return {
        "account_id": account_id,
        "current_balance": 52.00,
        "due_date": due,
        "plan_name": acct["plan"]["name"],
        "monthly_charge": acct["plan"]["monthly_price"],
        "autopay_enabled": True,
        "autopay_discount": 10.00,
        "recent_charges": [
            {"description": "5G 80GB Plan (base rate)", "amount": 47.00},
            {"description": "Autopay discount", "amount": -10.00},
            {"description": "Happy Tab - Galaxy S24", "amount": 15.00},
        ],
    }


def get_promotions() -> dict:
    """Get currently active Koodo promotions and deals.

    Returns:
        Dictionary with 'promotions' key containing list of active offers.
    """
    return {"promotions": _PROMOTIONS}


def check_network_status(region: str = "national") -> dict:
    """Check Koodo/TELUS network status and any active outages.

    Args:
        region: Region or city name to check. Defaults to 'national'.

    Returns:
        Network status with any active incidents.
    """
    return {
        "overall_status": "operational",
        "region": region,
        "active_incidents": [],
        "message": "All services operating normally on the TELUS 5G network.",
    }


def create_support_ticket(
    issue_category: str,
    description: str,
    phone_number: str = "",
    schedule_callback: bool = True,
) -> dict:
    """Create a support ticket and optionally schedule a callback with a live agent.

    Args:
        issue_category: Category of the issue: billing, technical, account, device, general.
        description: Description of the issue from the conversation.
        phone_number: Customer's phone number for callback.
        schedule_callback: Whether to schedule a callback. Defaults to True.

    Returns:
        Ticket confirmation with ID and estimated callback time.
    """
    ticket_id = f"TKT-{uuid.uuid4().hex[:8].upper()}"
    callback_time = (datetime.now() + timedelta(minutes=45)).strftime("%Y-%m-%d %H:%M")

    return {
        "ticket_id": ticket_id,
        "status": "open",
        "estimated_callback": callback_time if schedule_callback else None,
        "message": (
            f"Ticket {ticket_id} created. "
            + (
                f"A specialist will call you back around {callback_time}."
                if schedule_callback
                else "We'll follow up via the contact method on file."
            )
        ),
    }


def get_account(account_id: str) -> dict:
    """Get account details including plan, Tab balance, and lines. Requires authentication.

    Args:
        account_id: The account ID, e.g. 'ACC-001'.

    Returns:
        Account profile with plan details, Tab balance, and lines.
    """
    if account_id != "ACC-001":
        return {"error": "Account not found. For demo, use account_id 'ACC-001'."}

    acct = _MOCK_ACCOUNT
    return {
        "account_id": acct["account_id"],
        "name": acct["name"],
        "phone_number": acct["phone_number"],
        "plan": acct["plan"],
        "tab_balance": acct["tab_balance"],
        "lines": acct["lines"],
    }
