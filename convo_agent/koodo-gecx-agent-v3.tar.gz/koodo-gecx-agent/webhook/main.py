"""
Koodo Virtual Agent — Cloud Run Webhook Service

Standard REST API backend for GECX OpenAPI tools. CX Agent Studio calls
these endpoints via the OpenAPI tool specs registered in the console.

This is the SAME mock data as tools.py but exposed as HTTP endpoints.
In production, these would call real Koodo/TELUS backend systems.

Deploy:
  gcloud run deploy koodo-webhook --source . --region us-central1 --allow-unauthenticated

Production auth note:
  For production, remove --allow-unauthenticated and grant the CX Agent
  Studio service account (service-PROJECT_NUMBER@gcp-sa-ces.iam.gserviceaccount.com)
  the Cloud Run Invoker role (roles/run.invoker).
"""

import os
import uuid
from datetime import datetime, timedelta
from flask import Flask, request, jsonify

app = Flask(__name__)


# --- Inline mock data (same as tools.py) ---
# In production, replace with calls to real backend APIs

PLANS = [
    {"plan_id": "5g-20gb", "name": "5G 20GB Plan", "data_gb": 20,
     "monthly_price": 40.0, "autopay_discount": 10.0, "network_speed": "5G",
     "plan_type": "postpaid",
     "includes": ["Unlimited Canada-wide calling", "Unlimited international SMS",
                  "1 free perk of your choice"],
     "available_perks": ["Rollover Data", "5G Speed Boost",
                         "Unlimited Long Distance", "3-Day Easy Roam"]},
    {"plan_id": "5g-80gb", "name": "5G 80GB Plan", "data_gb": 80,
     "monthly_price": 50.0, "autopay_discount": 10.0, "network_speed": "5G",
     "plan_type": "postpaid",
     "includes": ["Unlimited Canada-wide calling", "Unlimited international SMS",
                  "20GB bonus data", "1 free perk of your choice"],
     "available_perks": ["Rollover Data", "5G Speed Boost",
                         "Unlimited Long Distance", "3-Day Easy Roam"]},
    {"plan_id": "5g-80gb-roam", "name": "5G 80GB CAN/US/MX Plan", "data_gb": 80,
     "monthly_price": 60.0, "autopay_discount": 10.0, "network_speed": "5G",
     "plan_type": "postpaid",
     "includes": ["Unlimited calling", "CAN/US/MX roaming", "1 free perk"],
     "available_perks": ["Rollover Data", "5G Speed Boost",
                         "Unlimited Long Distance", "3-Day Easy Roam"]},
]

DEVICES = [
    {"device_id": "samsung-galaxy-a57", "name": "Samsung Galaxy A57",
     "brand": "Samsung", "upfront_cost": 0, "monthly_tab": 15.0,
     "tab_type": "Happy Tab", "condition": "new", "in_stock": True,
     "colors": ["Black", "Lilac", "Light Blue"]},
    {"device_id": "google-pixel-10a", "name": "Google Pixel 10a",
     "brand": "Google", "upfront_cost": 0, "monthly_tab": 29.38,
     "tab_type": "Happy Tab", "condition": "new", "in_stock": True,
     "colors": ["Lavender", "Chalk", "Charcoal"]},
    {"device_id": "apple-iphone-air", "name": "Apple iPhone Air",
     "brand": "Apple", "upfront_cost": 0, "monthly_tab": 37.08,
     "tab_type": "Happy Tab Plus", "condition": "new", "in_stock": True,
     "colors": ["Sky Blue", "Starlight", "Midnight"]},
]


@app.route("/api/v1/plans", methods=["GET"])
def api_get_plans():
    plan_type = request.args.get("plan_type")
    min_data = request.args.get("min_data_gb", type=int)
    max_price = request.args.get("max_price", type=float)
    filtered = PLANS
    if plan_type:
        filtered = [p for p in filtered if p["plan_type"] == plan_type]
    if min_data:
        filtered = [p for p in filtered if p["data_gb"] >= min_data]
    if max_price:
        filtered = [p for p in filtered
                    if (p["monthly_price"] - p["autopay_discount"]) <= max_price]
    return jsonify({"plans": filtered})


@app.route("/api/v1/devices/<device_id>", methods=["GET"])
def api_get_device(device_id):
    device = next((d for d in DEVICES if d["device_id"] == device_id), None)
    if not device:
        return jsonify({"error": "Device not found"}), 404
    return jsonify(device)


@app.route("/api/v1/devices", methods=["GET"])
def api_get_devices():
    brand = request.args.get("brand")
    filtered = DEVICES
    if brand:
        filtered = [d for d in filtered if d["brand"].lower() == brand.lower()]
    return jsonify({"devices": [
        {"device_id": d["device_id"], "name": d["name"], "brand": d["brand"],
         "monthly_tab": d["monthly_tab"], "condition": d["condition"]}
        for d in filtered
    ]})


@app.route("/api/v1/account/<account_id>/billing", methods=["GET"])
def api_get_billing(account_id):
    if account_id != "ACC-001":
        return jsonify({"error": "Account not found"}), 404
    due = (datetime.now() + timedelta(days=14)).strftime("%Y-%m-%d")
    return jsonify({
        "account_id": account_id, "current_balance": 52.00, "due_date": due,
        "plan_name": "5G 80GB Plan", "monthly_charge": 47.00,
        "autopay_enabled": True, "autopay_discount": 10.00,
        "recent_charges": [
            {"description": "5G 80GB Plan (base rate)", "amount": 47.00},
            {"description": "Autopay discount", "amount": -10.00},
            {"description": "Happy Tab - Galaxy S24", "amount": 15.00},
        ],
    })


@app.route("/api/v1/promotions", methods=["GET"])
def api_get_promotions():
    return jsonify({"promotions": [
        {"name": "Free Connection Online", "discount_amount": 80.0,
         "description": "Save $80 connection fee when you order online."},
        {"name": "Refer a Friend", "discount_amount": 25.0,
         "description": "You and your friend each get $25 off."},
        {"name": "Stream+ Bundle", "discount_amount": 10.0,
         "description": "Apple TV + Stream+ from $20/mo for 3 months."},
    ]})


@app.route("/api/v1/network/status", methods=["GET"])
def api_check_network():
    return jsonify({"overall_status": "operational",
                    "region": request.args.get("region", "national"),
                    "active_incidents": []})


@app.route("/api/v1/support/tickets", methods=["POST"])
def api_create_ticket():
    data = request.get_json() or {}
    tid = f"TKT-{uuid.uuid4().hex[:8].upper()}"
    cb = (datetime.now() + timedelta(minutes=45)).strftime("%H:%M")
    return jsonify({"ticket_id": tid, "status": "open",
                    "estimated_callback": cb}), 201


@app.route("/api/v1/account/<account_id>", methods=["GET"])
def api_get_account(account_id):
    if account_id != "ACC-001":
        return jsonify({"error": "Account not found"}), 404
    return jsonify({
        "account_id": "ACC-001", "name": "Jane Doe",
        "phone_number": "416-555-1234",
        "plan": {"name": "5G 80GB Plan", "data_gb": 80, "monthly_price": 47.0},
        "tab_balance": 180.00,
    })


@app.route("/health", methods=["GET"])
def health():
    return jsonify({"status": "healthy"})


if __name__ == "__main__":
    app.run(host="0.0.0.0", port=int(os.environ.get("PORT", 8080)))
