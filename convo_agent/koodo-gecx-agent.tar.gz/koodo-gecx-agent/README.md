# Koodo Mobile Conversational Agent — GECX Multi-Agent Pipeline

## Architecture Overview

```
┌─────────────────────────────────────────────────────────┐
│                   ADK Multi-Agent Pipeline                │
│                                                           │
│  ┌──────────┐   ┌───────────┐   ┌──────────┐            │
│  │ Planner  │──▶│ Extractor │──▶│ Designer │            │
│  │  Agent   │   │   Agent   │   │  Agent   │            │
│  └──────────┘   └───────────┘   └──────────┘            │
│       │              │               │                    │
│       ▼              ▼               ▼                    │
│  task_plan.json  entities.json  cuj_flows.json           │
└─────────────────────────────────────────────────────────┘
                        │
                        ▼
┌─────────────────────────────────────────────────────────┐
│              CX Agent Studio (GECX)                      │
│                                                           │
│  ┌─────────────────┐  ┌──────────────┐                   │
│  │ Agent App Config │  │ OpenAPI Tools │                  │
│  │ (Instructions +  │  │ (per-CUJ     │                  │
│  │  Guardrails)     │  │  endpoints)  │                  │
│  └────────┬────────┘  └──────┬───────┘                   │
│           │                   │                           │
│           ▼                   ▼                           │
│  ┌──────────────────────────────────┐                    │
│  │     Cloud Run Webhook Service    │                    │
│  │  (Flask API — Mock Backend)      │                    │
│  └──────────────────────────────────┘                    │
└─────────────────────────────────────────────────────────┘
```

## Project Structure

```
koodo-gecx-agent/
├── agents/                    # ADK multi-agent pipeline
│   ├── __init__.py
│   ├── planner_agent.py       # Step 1: Scope & task decomposition
│   ├── extractor_agent.py     # Step 2: Entity/intent extraction
│   ├── designer_agent.py      # Step 3: CUJ conversation design
│   └── pipeline.py            # Orchestrator (runs all 3 sequentially)
├── config/                    # GECX deployment configs
│   ├── agent_app.json         # CX Agent Studio app config
│   ├── openapi_tools.yaml     # OpenAPI specs for tools
│   └── guardrails.json        # Safety guardrails config
├── webhook/                   # Cloud Run backend
│   ├── main.py                # Flask webhook service
│   ├── requirements.txt
│   ├── Dockerfile
│   └── deploy.sh              # gcloud run deploy script
├── docs/
│   └── requirements.md        # Full PRD (Steps 1-3 output)
└── README.md
```

## Quick Start

### 1. Run the ADK Pipeline (local)
```bash
cd agents/
pip install google-adk google-cloud-aiplatform
export GOOGLE_CLOUD_PROJECT=<your-project>
python pipeline.py
```

### 2. Deploy Webhook to Cloud Run
```bash
cd webhook/
chmod +x deploy.sh
./deploy.sh
```

### 3. Import to CX Agent Studio
1. Go to console.cloud.google.com → Customer Engagement AI → CX Agent Studio
2. Create new agent app
3. Paste instructions from `config/agent_app.json`
4. Add OpenAPI tool from `config/openapi_tools.yaml`
5. Point tool URL to your Cloud Run service URL
