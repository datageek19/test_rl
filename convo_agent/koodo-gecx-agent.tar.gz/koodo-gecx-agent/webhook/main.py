"""
Koodo Virtual Agent — Cloud Run Webhook Service

Mock backend that serves all OpenAPI tool endpoints for the GECX agent.
Deploy to Cloud Run and point CX Agent Studio OpenAPI tools here.

Usage:
    Local:  flask run --port 8080
    Deploy: See deploy.sh
"""

import os
import uuid
from datetime import datetime, timedelta
from flask import Flask, request, jsonify

app = Flask(__name__)

# =============================================================================
# Mock Data Store
# =============================================================================

PLANS = [
    {
        "plan_id": "5g-20gb",
        "name": "5G 20GB Plan",
        "data_gb": 20,
        "monthly_price": 40.00,
        "autopay_discount": 10.00,
        "network_speed": "5G",
        "plan_type": "postpaid",
        "includes": [
            "Unlimited Canada-wide calling",
            "Unlimited international SMS",
            "1 free perk of your choice",
        ],
        "available_perks": [
            "Rollover Data",
            "5G Speed Boost",
            "Unlimited Long Distance",
            "3-Day Easy Roam",
        ],
    },
    {
        "plan_id": "5g-80gb",
        "name": "5G 80GB Plan",
        "data_gb": 80,
        "monthly_price": 50.00,
        "autopay_discount": 10.00,
        "network_speed": "5G",
        "plan_type": "postpaid",
        "includes": [
            "Unlimited Canada-wide calling",
            "Unlimited international SMS",
            "20GB bonus data included",
            "1 free perk of your choice",
        ],
        "available_perks": [
            "Rollover Data",
            "5G Speed Boost",
            "Unlimited Long Distance",
            "3-Day Easy Roam",
        ],
    },
    {
        "plan_id": "5g-80gb-roam",
        "name": "5G 80GB Canada/US/Mexico Plan",
        "data_gb": 80,
        "monthly_price": 60.00,
        "autopay_discount": 10.00,
        "network_speed": "5G",
        "plan_type": "postpaid",
        "includes": [
            "Unlimited Canada-wide calling",
            "Unlimited international SMS",
            "Canada/US/Mexico roaming included",
            "1 free perk of your choice",
        ],
        "available_perks": [
            "Rollover Data",
            "5G Speed Boost",
            "Unlimited Long Distance",
            "3-Day Easy Roam",
        ],
    },
    {
        "plan_id": "5g-100gb-roam",
        "name": "5G 100GB Canada/US/Mexico Plan",
        "data_gb": 100,
        "monthly_price": 75.00,
        "autopay_discount": 10.00,
        "network_speed": "5G",
        "plan_type": "postpaid",
        "includes": [
            "Unlimited Canada-wide calling",
            "Unlimited international SMS",
            "Canada/US/Mexico roaming included",
            "Hotspot included",
            "1 free perk of your choice",
        ],
        "available_perks": [
            "Rollover Data",
            "5G Speed Boost",
            "Unlimited Long Distance",
            "3-Day Easy Roam",
        ],
    },
    {
        "plan_id": "prepaid-4gb",
        "name": "Prepaid 4GB Plan",
        "data_gb": 4,
        "monthly_price": 25.00,
        "autopay_discount": 0,
        "network_speed": "4G LTE",
        "plan_type": "prepaid",
        "includes": [
            "Unlimited Canada-wide calling",
            "Unlimited international SMS",
            "Bonus 500MB/mo with auto top-up",
        ],
        "available_perks": [],
    },
]

DEVICES = [
    {
        "device_id": "samsung-galaxy-a57",
        "name": "Samsung Galaxy A57",
        "brand": "Samsung",
        "upfront_cost": 0,
        "monthly_tab": 15.00,
        "tab_type": "Happy Tab",
        "condition": "new",
        "in_stock": True,
        "colors": ["Black", "Lilac", "Light Blue"],
    },
    {
        "device_id": "samsung-galaxy-a16",
        "name": "Samsung Galaxy A16",
        "brand": "Samsung",
        "upfront_cost": 0,
        "monthly_tab": 4.00,
        "tab_type": "Happy Tab",
        "condition": "new",
        "in_stock": True,
        "colors": ["Black", "Light Green"],
    },
    {
        "device_id": "samsung-galaxy-s24-cpo",
        "name": "Samsung Galaxy S24 (Certified Pre-Owned)",
        "brand": "Samsung",
        "upfront_cost": 0,
        "monthly_tab": 15.00,
        "tab_type": "Happy Tab",
        "condition": "certified_pre_owned",
        "in_stock": True,
        "colors": ["Amber Yellow", "Onyx Black"],
    },
    {
        "device_id": "google-pixel-10a",
        "name": "Google Pixel 10a",
        "brand": "Google",
        "upfront_cost": 0,
        "monthly_tab": 29.38,
        "tab_type": "Happy Tab",
        "condition": "new",
        "in_stock": True,
        "colors": ["Lavender", "Chalk", "Charcoal"],
    },
    {
        "device_id": "motorola-moto-g-2026",
        "name": "Motorola moto g - 2026",
        "brand": "Motorola",
        "upfront_cost": 0,
        "monthly_tab": 8.00,
        "tab_type": "Happy Tab",
        "condition": "new",
        "in_stock": True,
        "colors": ["Slipstream"],
    },
    {
        "device_id": "apple-iphone-air",
        "name": "Apple iPhone Air",
        "brand": "Apple",
        "upfront_cost": 0,
        "monthly_tab": 37.08,
        "tab_type": "Happy Tab Plus",
        "condition": "new",
        "in_stock": True,
        "colors": ["Sky Blue", "Starlight", "Midnight"],
    },
]

PROMOTIONS = [
    {
        "promo_id": "online-connection-fee",
        "name": "Free Connection Online",
        "description": "Save $80 connection fee when you order online and sign up for email deals.",
        "discount_amount": 80.00,
        "conditions": "Online orders only. Must sign up for Koodo email deals.",
        "expiry_date": None,
        "promo_type": "connection_fee_waiver",
    },
    {
        "promo_id": "refer-friend-25",
        "name": "Refer a Friend",
        "description": "Refer a friend to Koodo and you both get $25 off your bill.",
        "discount_amount": 25.00,
        "conditions": "Friend must activate a new postpaid plan. Share your referral code from Self Serve.",
        "expiry_date": None,
        "promo_type": "referral",
    },
    {
        "promo_id": "stream-plus-bundle",
        "name": "Stream+ Bundle with Apple TV",
        "description": "Bundle Apple TV with Stream+ starting from $20/mo for the first 3 months. Save $10/mo when bundled with your plan.",
        "discount_amount": 10.00,
        "conditions": "Eligible plans only. $20/mo for first 3 months, regular price after.",
        "expiry_date": None,
        "promo_type": "streaming_bundle",
    },
    {
        "promo_id": "pick-your-perk",
        "name": "Pick Your Perk",
        "description": "Choose one free perk with your eligible plan: Rollover Data, 5G Speed Boost, Unlimited Long Distance, or 3-Day Easy Roam. Switch anytime!",
        "discount_amount": 0,
        "conditions": "Available on eligible postpaid plans $40+/mo.",
        "expiry_date": None,
        "promo_type": "plan_feature",
    },
]

# Mock account for demo
MOCK_ACCOUNTS = {
    "ACC-001": {
        "account_id": "ACC-001",
        "name": "Jane Doe",
        "phone_number": "416-555-1234",
        "plan": {
            "name": "5G 80GB Plan",
            "data_gb": 80,
            "monthly_price": 47.00,
            "selected_perk": "Rollover Data",
        },
        "tab_balance": 180.00,
        "lines": [
            {
                "phone_number": "416-555-1234",
                "plan_name": "5G 80GB Plan",
                "device": "Samsung Galaxy S24",
            }
        ],
        "billing": {
            "current_balance": 47.00,
            "due_date": (datetime.now() + timedelta(days=14)).strftime("%Y-%m-%d"),
            "autopay_enabled": True,
            "autopay_discount": 10.00,
            "recent_charges": [
                {
                    "description": "5G 80GB Plan (base rate)",
                    "amount": 47.00,
                    "date": datetime.now().strftime("%Y-%m-%d"),
                },
                {
                    "description": "Autopay discount",
                    "amount": -10.00,
                    "date": datetime.now().strftime("%Y-%m-%d"),
                },
                {
                    "description": "Happy Tab - Galaxy S24",
                    "amount": 15.00,
                    "date": datetime.now().strftime("%Y-%m-%d"),
                },
            ],
        },
    }
}


# =============================================================================
# API Endpoints
# =============================================================================


@app.route("/api/v1/plans", methods=["GET"])
def get_plans():
    """Get available plans with optional filters."""
    plan_type = request.args.get("plan_type")
    min_data = request.args.get("min_data_gb", type=int)
    max_price = request.args.get("max_price", type=float)

    filtered = PLANS
    if plan_type:
        filtered = [p for p in filtered if p["plan_type"] == plan_type]
    if min_data:
        filtered = [p for p in filtered if p["data_gb"] >= min_data]
    if max_price:
        filtered = [
            p for p in filtered
            if (p["monthly_price"] - p["autopay_discount"]) <= max_price
        ]

    return jsonify({"plans": filtered})


@app.route("/api/v1/devices", methods=["GET"])
def get_devices_catalog():
    """List all available devices with optional filters."""
    brand = request.args.get("brand")
    condition = request.args.get("condition")
    max_monthly = request.args.get("max_monthly", type=float)

    filtered = DEVICES
    if brand:
        filtered = [d for d in filtered if d["brand"].lower() == brand.lower()]
    if condition:
        filtered = [d for d in filtered if d["condition"] == condition]
    if max_monthly:
        filtered = [d for d in filtered if d["monthly_tab"] <= max_monthly]

    # Return summary fields
    result = [
        {
            "device_id": d["device_id"],
            "name": d["name"],
            "brand": d["brand"],
            "monthly_tab": d["monthly_tab"],
            "upfront_cost": d["upfront_cost"],
            "condition": d["condition"],
        }
        for d in filtered
    ]
    return jsonify({"devices": result})


@app.route("/api/v1/devices/<device_id>", methods=["GET"])
def get_device(device_id):
    """Get details for a specific device."""
    device = next((d for d in DEVICES if d["device_id"] == device_id), None)
    if not device:
        return jsonify({"error": "Device not found"}), 404
    return jsonify(device)


@app.route("/api/v1/account/<account_id>/billing", methods=["GET"])
def get_billing(account_id):
    """Get billing information for an account."""
    account = MOCK_ACCOUNTS.get(account_id)
    if not account:
        return jsonify({"error": "Account not found"}), 404

    billing = account["billing"]
    return jsonify(
        {
            "account_id": account_id,
            "current_balance": billing["current_balance"],
            "due_date": billing["due_date"],
            "plan_name": account["plan"]["name"],
            "monthly_charge": account["plan"]["monthly_price"],
            "autopay_enabled": billing["autopay_enabled"],
            "autopay_discount": billing["autopay_discount"],
            "recent_charges": billing["recent_charges"],
        }
    )


@app.route("/api/v1/promotions", methods=["GET"])
def get_promotions():
    """Get current promotions."""
    return jsonify({"promotions": PROMOTIONS})


@app.route("/api/v1/network/status", methods=["GET"])
def check_network_status():
    """Check network status."""
    region = request.args.get("region", "national")
    return jsonify(
        {
            "overall_status": "operational",
            "region": region,
            "active_incidents": [],
        }
    )


@app.route("/api/v1/support/tickets", methods=["POST"])
def create_support_ticket():
    """Create a support ticket."""
    data = request.get_json() or {}
    ticket_id = f"TKT-{uuid.uuid4().hex[:8].upper()}"
    callback_time = (datetime.now() + timedelta(minutes=45)).strftime(
        "%Y-%m-%d %H:%M"
    )

    return (
        jsonify(
            {
                "ticket_id": ticket_id,
                "status": "open",
                "estimated_callback": callback_time
                if data.get("schedule_callback", True)
                else None,
                "message": f"Your ticket {ticket_id} has been created. "
                + (
                    f"A specialist will call you back around {callback_time}."
                    if data.get("schedule_callback", True)
                    else "We'll follow up via the contact method on file."
                ),
            }
        ),
        201,
    )


@app.route("/api/v1/account/<account_id>", methods=["GET"])
def get_account(account_id):
    """Get account details."""
    account = MOCK_ACCOUNTS.get(account_id)
    if not account:
        return jsonify({"error": "Account not found"}), 404

    return jsonify(
        {
            "account_id": account["account_id"],
            "name": account["name"],
            "phone_number": account["phone_number"],
            "plan": account["plan"],
            "tab_balance": account["tab_balance"],
            "lines": account["lines"],
        }
    )


@app.route("/health", methods=["GET"])
def health():
    """Health check endpoint for Cloud Run."""
    return jsonify({"status": "healthy", "service": "koodo-webhook"})


if __name__ == "__main__":
    port = int(os.environ.get("PORT", 8080))
    app.run(host="0.0.0.0", port=port, debug=True)
