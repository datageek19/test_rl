#!/bin/bash
# Deploy Koodo webhook service to Cloud Run
# Prerequisites: gcloud CLI authenticated, project set

set -euo pipefail

PROJECT_ID="${GOOGLE_CLOUD_PROJECT:-$(gcloud config get-value project)}"
REGION="${CLOUD_RUN_REGION:-us-central1}"
SERVICE_NAME="koodo-webhook"
IMAGE="gcr.io/${PROJECT_ID}/${SERVICE_NAME}"

echo "=== Deploying ${SERVICE_NAME} to Cloud Run ==="
echo "Project: ${PROJECT_ID}"
echo "Region:  ${REGION}"

# Build and push container
echo "Building container image..."
gcloud builds submit --tag "${IMAGE}" --project "${PROJECT_ID}"

# Deploy to Cloud Run
echo "Deploying to Cloud Run..."
gcloud run deploy "${SERVICE_NAME}" \
  --image "${IMAGE}" \
  --platform managed \
  --region "${REGION}" \
  --allow-unauthenticated \
  --memory 512Mi \
  --cpu 1 \
  --min-instances 0 \
  --max-instances 10 \
  --timeout 60 \
  --project "${PROJECT_ID}"

# Get service URL
SERVICE_URL=$(gcloud run services describe "${SERVICE_NAME}" \
  --region "${REGION}" \
  --project "${PROJECT_ID}" \
  --format "value(status.url)")

echo ""
echo "=== Deployment Complete ==="
echo "Service URL: ${SERVICE_URL}"
echo ""
echo "Next steps:"
echo "1. Update openapi_tools.yaml server URLs with: ${SERVICE_URL}"
echo "2. In CX Agent Studio, register each OpenAPI tool pointing to this URL"
echo "3. Test with: curl ${SERVICE_URL}/health"
echo "4. Test plans: curl ${SERVICE_URL}/api/v1/plans"
