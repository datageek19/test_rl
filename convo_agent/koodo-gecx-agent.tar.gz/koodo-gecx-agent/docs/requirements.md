# Koodo Mobile Conversational Agent — Product Requirements Document

**Version:** 1.0  
**Date:** April 14, 2026  
**Platform:** Google Cloud CX Agent Studio (GECX) + ADK  
**Status:** Draft — Ready for Engineering Review

---

## 1. Overview and Objectives

### 1.1 Purpose

Build an AI-powered conversational agent for Koodo Mobile that handles customer interactions across web chat, replacing or augmenting the existing Koodo Assist digital rep. The agent will run on Google Cloud Customer Engagement AI (CX Agent Studio) with a Cloud Run webhook backend.

### 1.2 Business Objectives

- Reduce average handle time for common inquiries (plan browsing, billing questions, basic troubleshooting) by 40-60%
- Deflect 70%+ of routine inquiries from live agents
- Maintain CSAT score ≥ 4.2/5.0 for AI-handled conversations
- Enable 24/7 self-service for account management tasks
- Drive online plan/device conversions through guided purchasing flows

### 1.3 Success Metrics

| Metric | Target | Measurement |
|--------|--------|-------------|
| Containment rate | ≥ 70% | % of conversations resolved without live agent |
| CSAT | ≥ 4.2/5.0 | Post-conversation survey |
| Average resolution time | < 3 min | For contained conversations |
| Handoff quality | ≥ 90% correct routing | Handoffs reach correct specialist team |
| Conversion rate | ≥ 5% | Plan/device purchases initiated through agent |

---

## 2. Scope

### 2.1 In-Scope

- Plan browsing, comparison, and recommendation (postpaid, prepaid, BYOD)
- Device catalog browsing and purchase guidance
- Billing inquiry (view bill, explain charges, payment guidance)
- Basic troubleshooting (network, device, SIM/eSIM)
- Account management (plan changes, add line, number porting, eSIM activation)
- Promotion and deal inquiries (referrals, streaming bundles, perks)
- Support ticket creation with callback scheduling
- Handoff to live agents for complex cases
- English language support (primary), French (secondary)

### 2.2 Out-of-Scope (Phase 1)

- Direct payment processing (redirect to Self Serve)
- Direct order completion (redirect to Koodo checkout)
- SIM card physical shipment tracking
- TELUS parent account operations
- Koodo Internet (home internet) — separate product line
- Voice channel (IVR) — web chat only for Phase 1
- Proactive outbound messaging
- Third-party integrations (Apple/Google wallet, banking)

### 2.3 Assumptions

- [ASSUMPTION] Plan pricing and device catalog data will be available via internal APIs; mock data used until integration
- [ASSUMPTION] Authentication will use existing Koodo Self Serve session tokens; mock auth for Phase 1
- [ASSUMPTION] Koodo brand guidelines and tone of voice align with the "friendly, casual, happy" direction observed on the website
- [ASSUMPTION] CX Agent Studio supports OpenAPI tool integration with Cloud Run endpoints
- [ASSUMPTION] The $80 connection fee waiver for online orders is an ongoing promotion, not time-limited

---

## 3. User Personas

### 3.1 New Customer — "Plan Shopper"

- **Demographics:** 18-35, price-conscious, comparing carriers
- **Goals:** Find best plan for budget, understand what's included, learn about perks
- **Behavior:** Asks broad questions, compares options, wants clear pricing
- **Auth status:** Unauthenticated
- **Key CUJs:** Browse Plans, Check Promotions, Purchase Device

### 3.2 Existing Customer — "Account Manager"

- **Demographics:** 25-50, already has Koodo service
- **Goals:** Check bill, change plan, manage account, troubleshoot
- **Behavior:** Expects quick answers, references existing service details
- **Auth status:** Authenticated
- **Key CUJs:** Check Billing, Account Management, Troubleshoot

### 3.3 Upgrader — "Device Buyer"

- **Demographics:** 20-40, wants a new phone
- **Goals:** Compare devices, understand Tab payment structure, check upgrade eligibility
- **Behavior:** Has specific devices in mind, asks about financing
- **Auth status:** May or may not be authenticated
- **Key CUJs:** Purchase Device, Browse Plans, Check Promotions

### 3.4 Frustrated Customer — "Issue Reporter"

- **Demographics:** Any age, experiencing a service problem
- **Goals:** Get service restored ASAP, understand what happened
- **Behavior:** Frustrated, wants fast resolution, may escalate
- **Auth status:** Varies
- **Key CUJs:** Troubleshoot, Check Billing (if billing-related)

---

## 4. Functional Requirements

### 4.1 Extracted Intents (7 Primary)

| Intent | Display Name | Auth Required | Primary CUJ |
|--------|-------------|---------------|-------------|
| `browse_plans` | Browse Plans | No | CUJ-001 |
| `purchase_device` | Purchase Device | No (upgrade: Yes) | CUJ-002 |
| `check_billing` | Check Billing | Yes | CUJ-003 |
| `troubleshoot_issue` | Troubleshoot Issue | No | CUJ-004 |
| `manage_account` | Manage Account | Yes | CUJ-005 |
| `check_promotions` | Check Promotions | No | CUJ-006 |
| `roaming_inquiry` | Roaming Inquiry | No | CUJ-001/006 |

### 4.2 Extracted Entities (12 Types)

| Entity Type | Example Values | Used In |
|-------------|---------------|---------|
| `@plan_type` | postpaid, prepaid, byod | browse_plans |
| `@data_gb` | 20GB, 80GB, 100GB | browse_plans |
| `@device_brand` | Apple, Samsung, Google, Motorola | purchase_device |
| `@device` | Samsung Galaxy A57, iPhone Air, Pixel 10a | purchase_device |
| `@device_condition` | new, certified_pre_owned | purchase_device |
| `@billing_action` | view_bill, make_payment, setup_autopay, dispute_charge | check_billing |
| `@account_action` | change_plan, add_line, port_number, activate_esim, cancel_service | manage_account |
| `@issue_category` | no_service, slow_data, call_issues, device_issue, voicemail | troubleshoot_issue |
| `@perk_type` | rollover_data, 5g_speed_boost, unlimited_long_distance, easy_roam_3day | browse_plans |
| `@promo_type` | referral, connection_fee_waiver, streaming_bundle, plan_discount | check_promotions |
| `@tab_type` | Happy Tab, Happy Tab Plus | purchase_device |
| `@country` | US, Mexico, (roaming destinations) | roaming_inquiry |

### 4.3 Knowledge Base (14 Snippets)

Organized across 6 categories covering the most common questions: plans (network, perks), billing (autopay setup), devices (Tab, CPO, Device Care), account (eSIM, porting, cancellation), support (Koodo Assist, contact info), and promotions (referral, connection fee waiver, streaming bundles). Full content in `agents/extractor_agent.py`.

### 4.4 Critical User Journeys

#### CUJ-001: Browse and Compare Plans

- **Trigger:** User asks about plans, pricing, data amounts
- **Flow:** Clarify usage needs → Call `get_plans` → Present filtered results with prices → Explain perks → Offer sign-up redirect
- **Tools:** `get_plans`
- **Edge cases:** Prepaid vs. postpaid confusion; plan no longer available; competitor comparison requests
- **Fallback:** Offer callback with sales specialist

#### CUJ-002: Purchase or Upgrade Plan/Device

- **Trigger:** User names a specific device or asks about buying a phone
- **Flow:** Look up device → Present pricing/Tab details → Determine new vs. existing customer → Recommend plan pairing → Provide order summary → Redirect to checkout
- **Tools:** `get_device`, `get_devices_catalog`, `get_plans`, `get_account` (for upgrades)
- **Edge cases:** Out of stock; CPO vs. new; Tab balance blocking upgrade; BYOD path
- **Fallback:** Create support ticket, schedule callback

#### CUJ-003: Check Billing and Payments

- **Trigger:** User asks about bill, charges, payments
- **Flow:** Verify identity → Call `get_billing` → Explain charges line by line → Address specific concerns → Guide to payment or autopay setup
- **Tools:** `get_billing`
- **Edge cases:** Price increase explanation (recent $7 hike); disputed charges; failed payment; no autopay discount
- **Fallback:** Handoff to billing specialist with context

#### CUJ-004: Troubleshoot Common Issues

- **Trigger:** User reports a problem (no signal, slow data, device issue)
- **Flow:** Identify issue type and device → Check network status → Provide step-by-step troubleshooting → Escalate if unresolved
- **Tools:** `check_network_status`, `create_support_ticket`
- **Edge cases:** Widespread outage; SIM/eSIM issue; account suspended; hardware failure
- **Fallback:** Create ticket with tech specialist callback

#### CUJ-005: Account Management

- **Trigger:** User wants to change plan, add line, port number, activate eSIM
- **Flow:** Verify identity → Determine action → Collect required info → Execute or redirect to Self Serve
- **Tools:** `get_account`
- **Edge cases:** Porting from specific carriers; eSIM device incompatibility; cancellation with Tab balance
- **Fallback:** Handoff to account specialist

#### CUJ-006: Promotions and Deals Inquiry

- **Trigger:** User asks about deals, current offers, referral program
- **Flow:** Call `get_promotions` → Present active deals → Answer follow-up questions → Direct to relevant CUJ for action
- **Tools:** `get_promotions`
- **Edge cases:** Expired promo; stacking restrictions; competitor price matching
- **Fallback:** Direct to koodomobile.com for latest offers

---

## 5. Non-Functional Requirements

### 5.1 Performance

| Requirement | Target |
|-------------|--------|
| Agent response latency (p50) | < 2 seconds |
| Agent response latency (p99) | < 5 seconds |
| Webhook response time | < 500ms |
| Concurrent conversations | 500+ |
| Availability | 99.9% uptime |

### 5.2 Scalability

- Cloud Run auto-scales 0-10 instances (expandable)
- CX Agent Studio handles session management natively
- Stateless webhook design — no session affinity required

### 5.3 Security and Compliance

- All PII handled per PIPEDA (Canadian privacy law)
- No storage of credit card numbers, SINs, or passwords in conversation logs
- Phone numbers masked in logs (show last 4 digits)
- Webhook endpoints secured via CX Agent Studio service account identity
- HTTPS-only communication
- VPC Service Controls recommended for production

### 5.4 Observability

- Cloud Trace for end-to-end request tracing
- CX Agent Studio conversation history for review
- Cloud Run logs for webhook debugging
- Custom metrics: containment rate, CSAT, intent accuracy, fallback rate

---

## 6. Conversational Design Principles

### 6.1 Brand Voice

Koodo's brand voice is **friendly, casual, and optimistic**. The agent should:

- Use contractions ("you'll", "we'll", "that's")
- Use positive language ("awesome", "great choice", "no sweat")
- Be direct and concise — respect the user's time
- Use emoji sparingly (only in informal contexts)
- Never use jargon without explanation

### 6.2 Conversation Structure

- **Greet** with energy, not formality: "Hey! How can I help?" not "Welcome to Koodo Mobile support."
- **Clarify** before assuming: ask one question at a time
- **Confirm** before acting: summarize what the agent will do
- **Recover** gracefully: acknowledge confusion, offer alternatives
- **Close** with next steps: always leave the user knowing what happens next

### 6.3 Escalation Protocol

1. **Attempt 1:** Agent tries to resolve with tools and KB
2. **Attempt 2:** Agent rephrases or offers alternative path
3. **Attempt 3:** Agent offers live agent callback with context handoff
4. **Hard escalation triggers:** User explicitly asks for human; safety concern; legal/regulatory topic; cancellation request (route to retention)

### 6.4 Multi-Turn Management

- Maintain context across turns within a session
- Reference previous answers ("Earlier you mentioned the 80GB plan...")
- Handle topic switches gracefully ("Sure, let me switch gears...")
- Proactively offer related help ("Since you're looking at plans, want to see phones too?")

---

## 7. Integration Architecture

### 7.1 High-Level Architecture

```
┌──────────────┐     ┌────────────────────────┐     ┌──────────────────┐
│   End User   │────▶│  CX Agent Studio       │────▶│  Cloud Run       │
│  (Web Chat)  │◀────│  (Gemini 2.5 Flash)    │◀────│  Webhook Service │
└──────────────┘     │                        │     │  (Flask API)     │
                     │  • Agent instructions   │     └────────┬─────────┘
                     │  • OpenAPI tools (8)     │              │
                     │  • Guardrails (5)        │              │
                     │  • KB (14 snippets)      │              ▼
                     └────────────────────────┘     ┌──────────────────┐
                                                     │  Backend APIs    │
                                                     │  (Phase 2: real  │
                                                     │   Koodo systems) │
                                                     └──────────────────┘
```

### 7.2 Component Inventory

| Component | Technology | Purpose |
|-----------|-----------|---------|
| Agent Runtime | CX Agent Studio (Gemini 2.5 Flash) | NLU, conversation management, tool orchestration |
| Agent Config | JSON instructions + guardrails | Behavior definition, safety rules |
| Tool Definitions | OpenAPI 3.0 specs (8 tools) | Interface contracts for backend |
| Webhook Service | Cloud Run + Flask | Mock/real API backend |
| Knowledge Base | CX Agent Studio data store | FAQ and policy answers |
| Observability | Cloud Trace + CX conversation history | Monitoring and debugging |
| Deployment | Cloud Run (auto-scaling) | Serverless backend hosting |

### 7.3 OpenAPI Tool Summary

| Tool | Method | Endpoint | Auth Required |
|------|--------|----------|---------------|
| `get_plans` | GET | `/api/v1/plans` | No |
| `get_device` | GET | `/api/v1/devices/{device_id}` | No |
| `get_devices_catalog` | GET | `/api/v1/devices` | No |
| `get_billing` | GET | `/api/v1/account/{id}/billing` | Yes (session) |
| `get_promotions` | GET | `/api/v1/promotions` | No |
| `check_network_status` | GET | `/api/v1/network/status` | No |
| `create_support_ticket` | POST | `/api/v1/support/tickets` | No |
| `get_account` | GET | `/api/v1/account/{id}` | Yes (session) |

### 7.4 Phase 2 Integration Roadmap

| Integration | System | Priority |
|------------|--------|----------|
| Plan catalog | Koodo product catalog API | High |
| Billing | TELUS billing system | High |
| Account management | Koodo Self Serve backend | High |
| Device inventory | Koodo/TELUS inventory system | Medium |
| Network status | TELUS network operations | Medium |
| Order placement | Koodo e-commerce platform | Medium |
| CRM ticketing | Koodo support CRM | Medium |
| Authentication | Koodo SSO / Self Serve auth | High |

---

## Appendix A: ADK Multi-Agent Pipeline

The extraction and design process is automated via a three-agent ADK pipeline:

1. **Planner Agent** — Analyzes Koodo's website and business context, produces a structured task plan with extraction categories and CUJ definitions
2. **Extractor Agent** — Processes website content per the task plan, outputs structured intents, entities, and knowledge base snippets
3. **Designer Agent** — Takes extractor output and produces detailed conversation flow designs for each CUJ with edge cases and fallback scenarios

Pipeline can run in mock mode (pre-computed outputs) or live mode (Gemini API calls). See `agents/pipeline.py`.

## Appendix B: Guardrail Configuration

Five guardrails are configured to protect the agent's behavior:

1. **no_competitor_pricing** — Prevents quoting specific competitor prices
2. **no_unauthorized_account_access** — Blocks account data without verification
3. **no_false_promises** — Prevents commitments not backed by tool responses
4. **privacy_protection** — Masks PII in conversation (credit cards, SINs)
5. **scope_boundary** — Keeps conversations within Koodo service topics
