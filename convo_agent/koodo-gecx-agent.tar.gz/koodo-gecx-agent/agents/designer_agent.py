"""
Designer Agent — Produces Critical User Journey (CUJ) conversation flows
for each identified user journey.

Consumes planner tasks + extractor output and produces conversation designs
with step-by-step flows, edge cases, and fallback scenarios.
"""

from google.adk.agents import LlmAgent
import json

DESIGNER_INSTRUCTION = """You are a conversational UX designer for telecom agents.

Given extracted intents, entities, and CUJ task definitions, produce detailed
conversation flow designs for each CUJ.

Output JSON:
{
  "cujs": [
    {
      "cuj_id": "CUJ-001",
      "name": "...",
      "user_intent": "...",
      "preconditions": ["..."],
      "conversation_flow": [
        {
          "step": 1,
          "actor": "user|agent",
          "utterance": "...",
          "action": "tool_call|respond|clarify|handoff",
          "tool_name": "...(if tool_call)",
          "next_step": 2
        }
      ],
      "edge_cases": [
        {"scenario": "...", "handling": "..."}
      ],
      "fallback": "...",
      "backend_integrations": ["..."]
    }
  ]
}

Design natural, empathetic conversations. Koodo's brand voice is
friendly, casual, and uses phrases like "happy", "awesome", "no sweat".
"""


def create_designer_agent() -> LlmAgent:
    """Create the designer agent with Gemini backend."""
    return LlmAgent(
        name="koodo_designer",
        model="gemini-2.5-flash",
        description="Designs CUJ conversation flows for the Koodo GECX agent.",
        instruction=DESIGNER_INSTRUCTION,
    )


# Pre-computed CUJ designs
KOODO_CUJ_DESIGNS = {
    "cujs": [
        {
            "cuj_id": "CUJ-001",
            "name": "Browse and Compare Plans",
            "user_intent": "Find the best mobile plan for my needs and budget",
            "preconditions": [],
            "conversation_flow": [
                {
                    "step": 1,
                    "actor": "user",
                    "utterance": "What plans do you have?",
                    "action": "trigger_intent",
                    "next_step": 2,
                },
                {
                    "step": 2,
                    "actor": "agent",
                    "utterance": "Awesome! I can help you find the perfect plan. To narrow things down — how much data do you usually use per month? Light (under 20GB), moderate (20-80GB), or heavy (80GB+)?",
                    "action": "clarify",
                    "next_step": 3,
                },
                {
                    "step": 3,
                    "actor": "user",
                    "utterance": "I'd say moderate, around 50GB.",
                    "action": "provide_parameter",
                    "next_step": 4,
                },
                {
                    "step": 4,
                    "actor": "agent",
                    "utterance": None,
                    "action": "tool_call",
                    "tool_name": "get_plans",
                    "tool_params": {"min_data_gb": 50},
                    "next_step": 5,
                },
                {
                    "step": 5,
                    "actor": "agent",
                    "utterance": "Here's what I'd recommend! Our 80GB 5G plan is $40/mo with autopay — it includes unlimited Canada-wide calling, texting, and you get to pick a free perk like Rollover Data or 3-Day Easy Roam. Would you like more details on this plan, or want to see other options?",
                    "action": "respond",
                    "next_step": 6,
                },
                {
                    "step": 6,
                    "actor": "user",
                    "utterance": "What perks can I pick?",
                    "action": "follow_up",
                    "next_step": 7,
                },
                {
                    "step": 7,
                    "actor": "agent",
                    "utterance": "You get one free perk with your plan — here are your options:\n• **Rollover Data** — unused data carries over to next month\n• **5G Speed Boost** — faster download speeds\n• **Unlimited Long Distance** — call internationally\n• **3-Day Easy Roam** — use your plan in the US for 3 days\nYou can switch your perk anytime too! Want to go ahead and sign up?",
                    "action": "respond",
                    "next_step": 8,
                },
            ],
            "edge_cases": [
                {
                    "scenario": "User asks for a plan not currently offered",
                    "handling": "Apologize and suggest the closest available plan. Mention that plan availability changes with promotions.",
                },
                {
                    "scenario": "User asks about prepaid specifically",
                    "handling": "Redirect to prepaid plans. Mention no credit check required and different data tiers available.",
                },
                {
                    "scenario": "User wants to compare Koodo with competitors",
                    "handling": "Focus on Koodo's strengths (TELUS network, perks, no contracts) without disparaging competitors.",
                },
            ],
            "fallback": "I'm not sure I found the right plan for you. Would you like me to connect you with a Koodo specialist who can help? I can schedule a callback.",
            "backend_integrations": ["GET /api/v1/plans"],
        },
        {
            "cuj_id": "CUJ-002",
            "name": "Purchase or Upgrade Plan/Device",
            "user_intent": "Buy a new phone or change my current plan",
            "preconditions": ["May require authentication for upgrades"],
            "conversation_flow": [
                {
                    "step": 1,
                    "actor": "user",
                    "utterance": "I want to get the Samsung Galaxy A57",
                    "action": "trigger_intent",
                    "next_step": 2,
                },
                {
                    "step": 2,
                    "actor": "agent",
                    "utterance": None,
                    "action": "tool_call",
                    "tool_name": "get_device",
                    "tool_params": {"device_name": "Samsung Galaxy A57"},
                    "next_step": 3,
                },
                {
                    "step": 3,
                    "actor": "agent",
                    "utterance": "Great choice! The Samsung Galaxy A57 is $0 upfront on Canada's largest 5G network. With the Happy Tab, you'd pay $15/mo for the device. Are you a current Koodo customer looking to upgrade, or are you new to Koodo?",
                    "action": "clarify",
                    "next_step": 4,
                },
                {
                    "step": 4,
                    "actor": "user",
                    "utterance": "I'm new to Koodo",
                    "action": "provide_parameter",
                    "next_step": 5,
                },
                {
                    "step": 5,
                    "actor": "agent",
                    "utterance": "Welcome! You'll need a plan to go with your phone. Based on the Galaxy A57, our 80GB 5G plan at $40/mo with autopay is a popular combo — that's $55/mo total. Plus, if you order online, the $80 connection fee is waived! Want me to walk you through the order?",
                    "action": "respond",
                    "next_step": 6,
                },
                {
                    "step": 6,
                    "actor": "user",
                    "utterance": "Yes, let's do it",
                    "action": "confirm",
                    "next_step": 7,
                },
                {
                    "step": 7,
                    "actor": "agent",
                    "utterance": "I'll redirect you to our secure checkout to complete the order. You'll need a valid Canadian ID and credit card. Here's your order summary:\n• Galaxy A57 — $0 upfront, $15/mo Tab\n• 80GB 5G Plan — $40/mo (with autopay)\n• Connection fee — WAIVED (online)\nTotal: $55/mo. Redirecting you now!",
                    "action": "handoff",
                    "handoff_url": "https://www.koodomobile.com/en/phones/samsung-galaxy-a57",
                    "next_step": None,
                },
            ],
            "edge_cases": [
                {
                    "scenario": "Device out of stock",
                    "handling": "Inform user and suggest similar alternatives. Offer to notify when back in stock.",
                },
                {
                    "scenario": "User wants CPO device",
                    "handling": "Show CPO options with pricing. Mention Limited Warranty included.",
                },
                {
                    "scenario": "Existing customer not eligible for upgrade",
                    "handling": "Explain Tab balance status and when they'll be eligible. Offer BYOD plan option.",
                },
            ],
            "fallback": "I couldn't complete that right now. Let me connect you to our team — I'll schedule a callback so someone can help you finish the order.",
            "backend_integrations": [
                "GET /api/v1/devices",
                "GET /api/v1/devices/{device_id}",
                "POST /api/v1/orders",
                "GET /api/v1/account/{id}/eligibility",
            ],
        },
        {
            "cuj_id": "CUJ-003",
            "name": "Check Billing and Payments",
            "user_intent": "View my bill, make a payment, or dispute a charge",
            "preconditions": ["User must be authenticated"],
            "conversation_flow": [
                {
                    "step": 1,
                    "actor": "user",
                    "utterance": "Why did my bill go up?",
                    "action": "trigger_intent",
                    "next_step": 2,
                },
                {
                    "step": 2,
                    "actor": "agent",
                    "utterance": "I can look into that for you! Let me pull up your billing details. Can you confirm your Koodo phone number?",
                    "action": "clarify",
                    "next_step": 3,
                },
                {
                    "step": 3,
                    "actor": "user",
                    "utterance": "416-555-1234",
                    "action": "provide_parameter",
                    "next_step": 4,
                },
                {
                    "step": 4,
                    "actor": "agent",
                    "utterance": None,
                    "action": "tool_call",
                    "tool_name": "get_billing",
                    "tool_params": {"phone_number": "4165551234"},
                    "next_step": 5,
                },
                {
                    "step": 5,
                    "actor": "agent",
                    "utterance": "I see your current bill is $47/mo, which is $7 more than before. Here's what happened: your base plan rate increased from $35 to $47, but your autopay discount also went up from $5 to $10 — so the net increase is $7/mo. If you don't agree with this change, you can cancel without penalty within 30 days. Would you like to explore other plan options that might save you money?",
                    "action": "respond",
                    "next_step": 6,
                },
            ],
            "edge_cases": [
                {
                    "scenario": "User wants to dispute a charge",
                    "handling": "Collect details about the disputed charge, create a support ticket, and confirm next steps.",
                },
                {
                    "scenario": "User hasn't set up autopay",
                    "handling": "Explain the autopay discount benefit and offer to guide through setup.",
                },
                {
                    "scenario": "User's payment failed",
                    "handling": "Suggest updating payment method in Self Serve. Provide deadline to avoid service interruption.",
                },
            ],
            "fallback": "I need a bit more info to help with your billing. Let me set up a callback with our billing team — they'll be able to pull up your full account details.",
            "backend_integrations": [
                "GET /api/v1/account/{id}/billing",
                "GET /api/v1/account/{id}/billing/history",
                "POST /api/v1/account/{id}/payment",
            ],
        },
        {
            "cuj_id": "CUJ-004",
            "name": "Troubleshoot Common Issues",
            "user_intent": "Fix problems with my phone, network, or service",
            "preconditions": [],
            "conversation_flow": [
                {
                    "step": 1,
                    "actor": "user",
                    "utterance": "I have no signal on my phone",
                    "action": "trigger_intent",
                    "next_step": 2,
                },
                {
                    "step": 2,
                    "actor": "agent",
                    "utterance": "No sweat, let's get that sorted! A few quick questions:\n1. What phone are you using?\n2. When did the issue start?\n3. Are you in a specific location, or is it happening everywhere?",
                    "action": "clarify",
                    "next_step": 3,
                },
                {
                    "step": 3,
                    "actor": "user",
                    "utterance": "iPhone 15, started today, happening everywhere",
                    "action": "provide_parameter",
                    "next_step": 4,
                },
                {
                    "step": 4,
                    "actor": "agent",
                    "utterance": None,
                    "action": "tool_call",
                    "tool_name": "check_network_status",
                    "tool_params": {},
                    "next_step": 5,
                },
                {
                    "step": 5,
                    "actor": "agent",
                    "utterance": "Network looks good in your area. Let's try these steps:\n1. Toggle Airplane Mode on, wait 10 seconds, then turn it off\n2. Restart your iPhone (hold Side + Volume down)\n3. Go to Settings > General > About — if a carrier update is available, install it\n\nDid any of those help?",
                    "action": "respond",
                    "next_step": 6,
                },
                {
                    "step": 6,
                    "actor": "user",
                    "utterance": "Still no luck",
                    "action": "negative_response",
                    "next_step": 7,
                },
                {
                    "step": 7,
                    "actor": "agent",
                    "utterance": "Let's try one more thing: go to Settings > General > Transfer or Reset iPhone > Reset Network Settings. This resets Wi-Fi and cellular settings but won't delete your data. If that doesn't work, I'll create a support ticket and schedule a callback with a tech specialist.",
                    "action": "respond",
                    "next_step": 8,
                },
            ],
            "edge_cases": [
                {
                    "scenario": "Widespread network outage",
                    "handling": "Acknowledge the outage, provide estimated resolution time if available, and offer to notify when resolved.",
                },
                {
                    "scenario": "SIM card issue",
                    "handling": "Guide user to check SIM seating. If eSIM, suggest removing and re-scanning. Offer replacement SIM if needed.",
                },
                {
                    "scenario": "Account suspended due to non-payment",
                    "handling": "Gently inform user and redirect to billing CUJ to make payment and restore service.",
                },
            ],
            "fallback": "I've done everything I can from here. Let me create a support ticket and get a Koodo tech specialist to call you back. They'll have more tools to diagnose the issue.",
            "backend_integrations": [
                "GET /api/v1/network/status",
                "POST /api/v1/support/tickets",
            ],
        },
        {
            "cuj_id": "CUJ-005",
            "name": "Account Management",
            "user_intent": "Update profile, manage eSIM, port number, add a line",
            "preconditions": ["User must be authenticated"],
            "conversation_flow": [
                {
                    "step": 1,
                    "actor": "user",
                    "utterance": "I want to add a second line to my account",
                    "action": "trigger_intent",
                    "next_step": 2,
                },
                {
                    "step": 2,
                    "actor": "agent",
                    "utterance": "Nice — adding a line is easy and keeps everything on one bill! Is this for yourself or another person? And do they have a phone already, or do they need one?",
                    "action": "clarify",
                    "next_step": 3,
                },
                {
                    "step": 3,
                    "actor": "user",
                    "utterance": "For my partner, they have their own phone",
                    "action": "provide_parameter",
                    "next_step": 4,
                },
                {
                    "step": 4,
                    "actor": "agent",
                    "utterance": "Perfect! They can bring their phone to Koodo with a BYOD plan. The 80GB 5G plan starts at $40/mo with autopay. If they want to keep their current number, we can port it over too. Want me to help start the activation?",
                    "action": "respond",
                    "next_step": 5,
                },
            ],
            "edge_cases": [
                {
                    "scenario": "User wants to port a number from another carrier",
                    "handling": "Collect: current carrier, account number, and PIN. Explain transfer timeline (few hours).",
                },
                {
                    "scenario": "User wants to cancel a line",
                    "handling": "Confirm which line, explain Tab balance implications, process or handoff to retention.",
                },
                {
                    "scenario": "eSIM activation failure",
                    "handling": "Verify device compatibility, resend QR code, or suggest visiting a Koodo store.",
                },
            ],
            "fallback": "Account changes need a bit of extra care. Let me connect you with a specialist who can make the changes securely.",
            "backend_integrations": [
                "GET /api/v1/account/{id}",
                "PATCH /api/v1/account/{id}",
                "POST /api/v1/account/{id}/lines",
            ],
        },
        {
            "cuj_id": "CUJ-006",
            "name": "Promotions and Deals Inquiry",
            "user_intent": "Learn about current offers, referral bonuses, and streaming bundles",
            "preconditions": [],
            "conversation_flow": [
                {
                    "step": 1,
                    "actor": "user",
                    "utterance": "Any deals right now?",
                    "action": "trigger_intent",
                    "next_step": 2,
                },
                {
                    "step": 2,
                    "actor": "agent",
                    "utterance": None,
                    "action": "tool_call",
                    "tool_name": "get_promotions",
                    "tool_params": {},
                    "next_step": 3,
                },
                {
                    "step": 3,
                    "actor": "agent",
                    "utterance": "Here's what's on right now:\n• **$0 connection fee** — order online and save $80\n• **Refer a Friend** — you and your friend each get $25 off\n• **Stream+ Bundle** — Apple TV + streaming from $20/mo for 3 months\n• **Pick a Perk** — free perk with eligible plans (like 3-Day Easy Roam!)\n\nAnything catch your eye?",
                    "action": "respond",
                    "next_step": 4,
                },
            ],
            "edge_cases": [
                {
                    "scenario": "Promotion has expired",
                    "handling": "Inform user the specific promo ended. Show current active promotions instead.",
                },
                {
                    "scenario": "User asks about a competitor's deal",
                    "handling": "Acknowledge, then highlight Koodo's comparable offers without disparaging competitors.",
                },
                {
                    "scenario": "User wants to stack multiple promotions",
                    "handling": "Explain which promotions can be combined and which are exclusive.",
                },
            ],
            "fallback": "I'm having trouble loading our latest deals. You can always check koodomobile.com/en for the most up-to-date offers, or I can schedule a callback!",
            "backend_integrations": ["GET /api/v1/promotions"],
        },
    ]
}

if __name__ == "__main__":
    print(json.dumps(KOODO_CUJ_DESIGNS, indent=2))
