"""
Pipeline Orchestrator — Runs the Planner → Extractor → Designer agent pipeline.

Can run in two modes:
1. **Live mode**: Uses ADK agents with Gemini to generate outputs dynamically
2. **Mock mode**: Uses pre-computed outputs for testing without API calls

Usage:
    python pipeline.py              # Mock mode (no API calls)
    python pipeline.py --live       # Live mode (requires GOOGLE_CLOUD_PROJECT)
"""

import argparse
import asyncio
import json
import os
import sys

from planner_agent import (
    create_planner_agent,
    KOODO_TASK_PLAN,
)
from extractor_agent import (
    create_extractor_agent,
    KOODO_EXTRACTION,
)
from designer_agent import (
    create_designer_agent,
    KOODO_CUJ_DESIGNS,
)


async def run_live_pipeline():
    """Run the full ADK pipeline with live Gemini calls."""
    from google.adk.runners import Runner
    from google.adk.sessions import InMemorySessionService

    session_service = InMemorySessionService()

    # --- Step 1: Planner ---
    print("=" * 60)
    print("STEP 1: Running Planner Agent...")
    print("=" * 60)

    planner = create_planner_agent()
    planner_runner = Runner(
        agent=planner,
        app_name="koodo_pipeline",
        session_service=session_service,
    )

    session = await session_service.create_session(
        app_name="koodo_pipeline", user_id="pipeline"
    )

    planner_prompt = """Analyze Koodo Mobile (koodomobile.com), a Canadian TELUS flanker brand.
    They offer 5G postpaid plans starting from $40/mo with perks (Rollover Data,
    5G Speed Boost, Easy Roam, Long Distance). Devices include Samsung Galaxy A57,
    Google Pixel 10a, iPhone Air, Motorola moto g 2026. They have the Koodo Tab
    (no fixed-term contracts), prepaid plans, eSIM activation, $25 referral credits,
    Stream+ bundles, and support via Koodo Assist (24/7 digital rep).
    Produce the structured task plan."""

    planner_result = None
    async for event in planner_runner.run_async(
        user_id="pipeline",
        session_id=session.id,
        new_message=planner_prompt,
    ):
        if event.is_final_response():
            planner_result = event.content.parts[0].text
            break

    print(f"Planner output: {planner_result[:500]}...")

    # --- Step 2: Extractor ---
    print("\n" + "=" * 60)
    print("STEP 2: Running Extractor Agent...")
    print("=" * 60)

    extractor = create_extractor_agent()
    extractor_runner = Runner(
        agent=extractor,
        app_name="koodo_pipeline",
        session_service=session_service,
    )

    session2 = await session_service.create_session(
        app_name="koodo_pipeline", user_id="pipeline"
    )

    extractor_prompt = f"""Given this task plan:
    {planner_result}

    Extract all intents, entities, and knowledge base snippets for Koodo Mobile."""

    extractor_result = None
    async for event in extractor_runner.run_async(
        user_id="pipeline",
        session_id=session2.id,
        new_message=extractor_prompt,
    ):
        if event.is_final_response():
            extractor_result = event.content.parts[0].text
            break

    print(f"Extractor output: {extractor_result[:500]}...")

    # --- Step 3: Designer ---
    print("\n" + "=" * 60)
    print("STEP 3: Running Designer Agent...")
    print("=" * 60)

    designer = create_designer_agent()
    designer_runner = Runner(
        agent=designer,
        app_name="koodo_pipeline",
        session_service=session_service,
    )

    session3 = await session_service.create_session(
        app_name="koodo_pipeline", user_id="pipeline"
    )

    designer_prompt = f"""Given these extracted intents/entities:
    {extractor_result}

    Design conversation flows for all 6 CUJs for the Koodo Mobile agent."""

    designer_result = None
    async for event in designer_runner.run_async(
        user_id="pipeline",
        session_id=session3.id,
        new_message=designer_prompt,
    ):
        if event.is_final_response():
            designer_result = event.content.parts[0].text
            break

    print(f"Designer output: {designer_result[:500]}...")

    return planner_result, extractor_result, designer_result


def run_mock_pipeline():
    """Run the pipeline with pre-computed outputs (no API calls)."""
    print("=" * 60)
    print("STEP 1: Planner Agent (mock)")
    print("=" * 60)
    print(f"  Provider: {KOODO_TASK_PLAN['provider']['name']}")
    print(f"  Extraction tasks: {len(KOODO_TASK_PLAN['extraction_tasks'])}")
    print(f"  CUJ tasks: {len(KOODO_TASK_PLAN['cuj_tasks'])}")
    for cuj in KOODO_TASK_PLAN["cuj_tasks"]:
        print(f"    [{cuj['priority'].upper()}] {cuj['cuj_id']}: {cuj['name']}")

    print("\n" + "=" * 60)
    print("STEP 2: Extractor Agent (mock)")
    print("=" * 60)
    print(f"  Intents extracted: {len(KOODO_EXTRACTION['intents'])}")
    print(f"  Entity types: {len(KOODO_EXTRACTION['entities'])}")
    print(f"  KB snippets: {len(KOODO_EXTRACTION['knowledge_base'])}")
    for intent in KOODO_EXTRACTION["intents"]:
        print(f"    Intent: {intent['intent_name']} ({len(intent['training_phrases'])} phrases)")

    print("\n" + "=" * 60)
    print("STEP 3: Designer Agent (mock)")
    print("=" * 60)
    print(f"  CUJ flows designed: {len(KOODO_CUJ_DESIGNS['cujs'])}")
    for cuj in KOODO_CUJ_DESIGNS["cujs"]:
        print(f"    {cuj['cuj_id']}: {cuj['name']} ({len(cuj['conversation_flow'])} steps, {len(cuj['edge_cases'])} edge cases)")

    # Write outputs
    os.makedirs("output", exist_ok=True)
    with open("output/task_plan.json", "w") as f:
        json.dump(KOODO_TASK_PLAN, f, indent=2)
    with open("output/extraction.json", "w") as f:
        json.dump(KOODO_EXTRACTION, f, indent=2)
    with open("output/cuj_designs.json", "w") as f:
        json.dump(KOODO_CUJ_DESIGNS, f, indent=2)

    print("\n✓ Outputs written to agents/output/")
    return KOODO_TASK_PLAN, KOODO_EXTRACTION, KOODO_CUJ_DESIGNS


if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument("--live", action="store_true", help="Use live Gemini API calls")
    args = parser.parse_args()

    if args.live:
        if not os.environ.get("GOOGLE_CLOUD_PROJECT"):
            print("ERROR: Set GOOGLE_CLOUD_PROJECT env var for live mode")
            sys.exit(1)
        asyncio.run(run_live_pipeline())
    else:
        run_mock_pipeline()
