"""
Planner Agent — Decomposes the Koodo GECX build into structured tasks.

This agent takes the high-level goal (build a telecom conversational agent)
and outputs a structured task plan for the extractor and designer agents.
"""

from google.adk.agents import LlmAgent
from google.adk.tools import FunctionTool
import json

PLANNER_INSTRUCTION = """You are a telecom conversational AI planner.

Given a telecom provider's website content and business context, produce a
structured task plan as JSON with exactly these keys:

{
  "provider": {
    "name": "...",
    "parent_brand": "...",
    "market": "...",
    "network": "..."
  },
  "extraction_tasks": [
    {
      "category": "plans|devices|billing|support|account|promotions",
      "source_urls": ["..."],
      "expected_entities": ["..."],
      "priority": "high|medium|low"
    }
  ],
  "cuj_tasks": [
    {
      "cuj_id": "CUJ-001",
      "name": "...",
      "user_goal": "...",
      "requires_auth": true|false,
      "backend_apis_needed": ["..."],
      "priority": "high|medium|low"
    }
  ]
}

Focus on the 6 core telecom CUJs:
1. Browse/compare plans
2. Purchase or upgrade plan/device
3. Check billing and payments
4. Troubleshoot common issues
5. Account management
6. Promotions and deals

Be specific to the provider. Use real plan names, real device names,
and real features you find in the content.
"""


def create_planner_agent() -> LlmAgent:
    """Create the planner agent with Gemini backend."""
    return LlmAgent(
        name="koodo_planner",
        model="gemini-2.5-flash",
        description="Plans the GECX agent build by decomposing into extraction and design tasks.",
        instruction=PLANNER_INSTRUCTION,
    )


# Pre-computed plan based on Koodo website extraction (for offline/mock use)
KOODO_TASK_PLAN = {
    "provider": {
        "name": "Koodo Mobile",
        "parent_brand": "TELUS",
        "market": "Canada",
        "network": "TELUS 5G / 4G LTE (largest network in Canada)",
    },
    "extraction_tasks": [
        {
            "category": "plans",
            "source_urls": [
                "https://www.koodomobile.com/en/shop/mobility/bring-your-own-phone",
                "https://www.koodomobile.com/en/prepaid-plans",
            ],
            "expected_entities": [
                "plan_name",
                "data_gb",
                "monthly_price",
                "autopay_discount",
                "network_speed",
                "perks",
                "roaming_coverage",
            ],
            "priority": "high",
        },
        {
            "category": "devices",
            "source_urls": ["https://www.koodomobile.com/en/phones"],
            "expected_entities": [
                "device_name",
                "brand",
                "monthly_tab_cost",
                "upfront_cost",
                "tab_type",
                "condition",
            ],
            "priority": "high",
        },
        {
            "category": "billing",
            "source_urls": ["https://www.koodomobile.com/en/help"],
            "expected_entities": [
                "payment_method",
                "billing_cycle",
                "autopay_setup",
                "bill_credit",
            ],
            "priority": "high",
        },
        {
            "category": "support",
            "source_urls": [
                "https://www.koodomobile.com/en/help/koodo-assist",
                "https://community.koodomobile.com",
            ],
            "expected_entities": [
                "support_channel",
                "hours_of_operation",
                "issue_category",
            ],
            "priority": "medium",
        },
        {
            "category": "account",
            "source_urls": ["https://www.koodomobile.com/en/help"],
            "expected_entities": [
                "self_serve_action",
                "esim_activation",
                "number_porting",
                "add_line",
            ],
            "priority": "medium",
        },
        {
            "category": "promotions",
            "source_urls": ["https://www.koodomobile.com/en"],
            "expected_entities": [
                "promo_name",
                "discount_amount",
                "promo_conditions",
                "expiry_date",
            ],
            "priority": "medium",
        },
    ],
    "cuj_tasks": [
        {
            "cuj_id": "CUJ-001",
            "name": "Browse and Compare Plans",
            "user_goal": "Find the best mobile plan for my needs and budget",
            "requires_auth": False,
            "backend_apis_needed": ["GET /plans", "GET /plans/{plan_id}"],
            "priority": "high",
        },
        {
            "cuj_id": "CUJ-002",
            "name": "Purchase or Upgrade Plan/Device",
            "user_goal": "Buy a new phone or change my current plan",
            "requires_auth": True,
            "backend_apis_needed": [
                "GET /devices",
                "POST /orders",
                "GET /account/{id}/eligibility",
            ],
            "priority": "high",
        },
        {
            "cuj_id": "CUJ-003",
            "name": "Check Billing and Payments",
            "user_goal": "View my bill, make a payment, or dispute a charge",
            "requires_auth": True,
            "backend_apis_needed": [
                "GET /account/{id}/billing",
                "POST /account/{id}/payment",
            ],
            "priority": "high",
        },
        {
            "cuj_id": "CUJ-004",
            "name": "Troubleshoot Common Issues",
            "user_goal": "Fix problems with my phone, network, or service",
            "requires_auth": False,
            "backend_apis_needed": [
                "POST /support/tickets",
                "GET /network/status",
            ],
            "priority": "medium",
        },
        {
            "cuj_id": "CUJ-005",
            "name": "Account Management",
            "user_goal": "Update profile, manage eSIM, port number, add a line",
            "requires_auth": True,
            "backend_apis_needed": [
                "GET /account/{id}",
                "PATCH /account/{id}",
                "POST /account/{id}/lines",
            ],
            "priority": "medium",
        },
        {
            "cuj_id": "CUJ-006",
            "name": "Promotions and Deals Inquiry",
            "user_goal": "Learn about current offers, referral bonuses, and streaming bundles",
            "requires_auth": False,
            "backend_apis_needed": ["GET /promotions", "POST /referrals"],
            "priority": "medium",
        },
    ],
}


if __name__ == "__main__":
    print(json.dumps(KOODO_TASK_PLAN, indent=2))
