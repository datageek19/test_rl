"""
Extractor Agent — Extracts intents, entities, and knowledge base snippets
from Koodo Mobile website content.

Consumes the planner's task plan and produces structured extraction output
that feeds into the designer agent and GECX config.
"""

from google.adk.agents import LlmAgent
import json

EXTRACTOR_INSTRUCTION = """You are a telecom data extraction specialist.

Given website content and an extraction task plan, extract and structure:

1. **Intents** — user goals mapped to GECX intent names
2. **Entities** — typed parameters (plan names, prices, device models, etc.)
3. **Knowledge Base Snippets** — FAQ answers, policy statements, help content

Output strict JSON:
{
  "intents": [
    {
      "intent_name": "browse_plans",
      "display_name": "Browse Plans",
      "training_phrases": ["show me plans", "what plans do you have"],
      "parameters": [{"name": "...", "entity_type": "...", "required": false}]
    }
  ],
  "entities": {
    "entity_type_name": {
      "values": [{"value": "...", "synonyms": ["..."]}]
    }
  },
  "knowledge_base": [
    {
      "question": "...",
      "answer": "...",
      "category": "plans|billing|support|account|devices|promotions"
    }
  ]
}

Be exhaustive. Extract real data from the provider's content.
"""


def create_extractor_agent() -> LlmAgent:
    """Create the extractor agent with Gemini backend."""
    return LlmAgent(
        name="koodo_extractor",
        model="gemini-2.5-flash",
        description="Extracts intents, entities, and KB snippets from telecom website content.",
        instruction=EXTRACTOR_INSTRUCTION,
    )


# Pre-computed extraction based on Koodo website content
KOODO_EXTRACTION = {
    "intents": [
        {
            "intent_name": "browse_plans",
            "display_name": "Browse Plans",
            "training_phrases": [
                "show me your plans",
                "what plans do you have",
                "I need a new plan",
                "compare plans",
                "how much is the 80GB plan",
                "what's the cheapest plan",
                "5G plans available",
                "do you have prepaid plans",
            ],
            "parameters": [
                {"name": "data_amount", "entity_type": "@data_gb", "required": False},
                {"name": "plan_type", "entity_type": "@plan_type", "required": False},
                {"name": "budget", "entity_type": "@sys.number", "required": False},
            ],
        },
        {
            "intent_name": "purchase_device",
            "display_name": "Purchase Device",
            "training_phrases": [
                "I want to buy a phone",
                "show me iPhones",
                "Samsung Galaxy A57 price",
                "what phones can I get for $0 upfront",
                "certified pre-owned phones",
                "how does the Koodo Tab work",
                "upgrade my phone",
            ],
            "parameters": [
                {"name": "device_name", "entity_type": "@device", "required": False},
                {"name": "brand", "entity_type": "@device_brand", "required": False},
                {"name": "condition", "entity_type": "@device_condition", "required": False},
            ],
        },
        {
            "intent_name": "check_billing",
            "display_name": "Check Billing",
            "training_phrases": [
                "view my bill",
                "how much do I owe",
                "make a payment",
                "when is my bill due",
                "set up autopay",
                "why did my bill go up",
                "dispute a charge",
                "what's autopay discount",
            ],
            "parameters": [
                {"name": "billing_action", "entity_type": "@billing_action", "required": False},
            ],
        },
        {
            "intent_name": "troubleshoot_issue",
            "display_name": "Troubleshoot Issue",
            "training_phrases": [
                "my phone isn't working",
                "no signal",
                "can't connect to network",
                "slow data speed",
                "can't make calls",
                "phone won't turn on",
                "reset my voicemail",
            ],
            "parameters": [
                {"name": "issue_type", "entity_type": "@issue_category", "required": False},
                {"name": "device_type", "entity_type": "@device", "required": False},
            ],
        },
        {
            "intent_name": "manage_account",
            "display_name": "Manage Account",
            "training_phrases": [
                "update my address",
                "change my plan",
                "add a line",
                "port my number to Koodo",
                "activate eSIM",
                "reset my self serve password",
                "cancel my service",
            ],
            "parameters": [
                {"name": "account_action", "entity_type": "@account_action", "required": False},
            ],
        },
        {
            "intent_name": "check_promotions",
            "display_name": "Check Promotions",
            "training_phrases": [
                "any deals right now",
                "current promotions",
                "refer a friend",
                "how do I get $25 credit",
                "connection fee waived",
                "streaming bundle price",
                "pick a perk options",
            ],
            "parameters": [
                {"name": "promo_type", "entity_type": "@promo_type", "required": False},
            ],
        },
        {
            "intent_name": "roaming_inquiry",
            "display_name": "Roaming Inquiry",
            "training_phrases": [
                "will my phone work in the US",
                "roaming charges",
                "Easy Roam cost",
                "travel to Mexico with my plan",
                "avoid roaming fees",
            ],
            "parameters": [
                {"name": "destination", "entity_type": "@country", "required": False},
            ],
        },
    ],
    "entities": {
        "@plan_type": {
            "values": [
                {"value": "postpaid", "synonyms": ["monthly plan", "contract", "tab plan"]},
                {"value": "prepaid", "synonyms": ["pay as you go", "no contract", "prepaid plan"]},
                {"value": "byod", "synonyms": ["bring your own phone", "BYOP", "bring your own device"]},
            ]
        },
        "@data_gb": {
            "values": [
                {"value": "20GB", "synonyms": ["20 gigs", "twenty gigabytes"]},
                {"value": "80GB", "synonyms": ["80 gigs", "eighty gigabytes"]},
                {"value": "100GB", "synonyms": ["100 gigs", "hundred gigabytes"]},
            ]
        },
        "@device_brand": {
            "values": [
                {"value": "Apple", "synonyms": ["iPhone", "iOS"]},
                {"value": "Samsung", "synonyms": ["Galaxy"]},
                {"value": "Google", "synonyms": ["Pixel"]},
                {"value": "Motorola", "synonyms": ["Moto"]},
            ]
        },
        "@device": {
            "values": [
                {"value": "Samsung Galaxy A57", "synonyms": ["Galaxy A57", "A57"]},
                {"value": "Samsung Galaxy A16", "synonyms": ["Galaxy A16", "A16"]},
                {"value": "Samsung Galaxy S24 CPO", "synonyms": ["Galaxy S24 pre-owned"]},
                {"value": "Google Pixel 10a", "synonyms": ["Pixel 10a"]},
                {"value": "Motorola moto g 2026", "synonyms": ["moto g 2026", "moto g"]},
                {"value": "Apple iPhone Air", "synonyms": ["iPhone Air"]},
            ]
        },
        "@device_condition": {
            "values": [
                {"value": "new", "synonyms": ["brand new", "latest"]},
                {"value": "certified_pre_owned", "synonyms": ["CPO", "pre-owned", "refurbished", "used"]},
            ]
        },
        "@billing_action": {
            "values": [
                {"value": "view_bill", "synonyms": ["see my bill", "check balance", "how much do I owe"]},
                {"value": "make_payment", "synonyms": ["pay bill", "pay now"]},
                {"value": "setup_autopay", "synonyms": ["automatic payment", "pre-authorized debit"]},
                {"value": "dispute_charge", "synonyms": ["wrong charge", "overcharged", "billing error"]},
            ]
        },
        "@account_action": {
            "values": [
                {"value": "change_plan", "synonyms": ["switch plan", "upgrade plan", "downgrade"]},
                {"value": "add_line", "synonyms": ["add another number", "new line", "second line"]},
                {"value": "port_number", "synonyms": ["transfer number", "move number", "keep my number"]},
                {"value": "activate_esim", "synonyms": ["eSIM setup", "digital SIM", "scan QR code"]},
                {"value": "update_profile", "synonyms": ["change address", "update email", "change name"]},
                {"value": "cancel_service", "synonyms": ["cancel", "deactivate", "close account"]},
            ]
        },
        "@issue_category": {
            "values": [
                {"value": "no_service", "synonyms": ["no signal", "no network", "no bars"]},
                {"value": "slow_data", "synonyms": ["slow internet", "buffering", "data slow"]},
                {"value": "call_issues", "synonyms": ["can't make calls", "dropped calls", "call quality"]},
                {"value": "device_issue", "synonyms": ["phone not working", "frozen screen", "won't charge"]},
                {"value": "voicemail", "synonyms": ["voicemail setup", "reset voicemail", "can't access voicemail"]},
            ]
        },
        "@perk_type": {
            "values": [
                {"value": "rollover_data", "synonyms": ["data rollover", "carry over data"]},
                {"value": "unlimited_long_distance", "synonyms": ["long distance pack", "international calls"]},
                {"value": "5g_speed_boost", "synonyms": ["5G boost", "faster speeds"]},
                {"value": "easy_roam_3day", "synonyms": ["3-Day Easy Roam", "roaming perk", "travel perk"]},
            ]
        },
        "@promo_type": {
            "values": [
                {"value": "referral", "synonyms": ["refer a friend", "friend referral", "$25 credit"]},
                {"value": "connection_fee_waiver", "synonyms": ["no connection fee", "waive $80 fee"]},
                {"value": "streaming_bundle", "synonyms": ["Stream+", "Apple TV bundle", "streaming deal"]},
                {"value": "plan_discount", "synonyms": ["sale", "flash sale", "limited time offer"]},
            ]
        },
        "@tab_type": {
            "values": [
                {"value": "Happy Tab", "synonyms": ["regular tab", "standard tab"]},
                {"value": "Happy Tab Plus", "synonyms": ["tab plus", "premium tab"]},
            ]
        },
    },
    "knowledge_base": [
        {
            "question": "What is the Koodo Tab?",
            "answer": "The Koodo Tab lets you get a phone from $0 upfront with no fixed-term contracts. You pay a monthly Tab charge on top of your plan, and you get a Tab Bonus discount. You can pay off your Tab anytime without penalty.",
            "category": "devices",
        },
        {
            "question": "What perks can I choose with my plan?",
            "answer": "Koodo offers one free perk with eligible plans: Rollover Data (unused data carries over), Unlimited Long Distance Pack, 5G Speed Boost, or 3-Day Easy Roam. You can switch your perk anytime.",
            "category": "plans",
        },
        {
            "question": "How do I set up autopay?",
            "answer": "Log in to Self Serve at koodomobile.com or the Koodo app, go to Billing, and set up pre-authorized debit with a credit card or bank account. You get up to $10/month discount with autopay.",
            "category": "billing",
        },
        {
            "question": "How do I port my number to Koodo?",
            "answer": "You can move your existing number to Koodo during activation online or in-store. You'll need your current account number and PIN from your old provider. The transfer typically completes within a few hours.",
            "category": "account",
        },
        {
            "question": "What is Koodo Assist?",
            "answer": "Koodo Assist is a digital rep available 24/7 that can answer questions, make account changes, top up data, add Easy Roam, and reset passwords. If it can't solve your issue, it schedules a callback with a live agent, usually within 30 minutes to an hour.",
            "category": "support",
        },
        {
            "question": "How does the referral program work?",
            "answer": "Refer a friend to Koodo and you both get $25 off your bill. Share your referral code from Self Serve. Your friend must activate a new postpaid plan for both credits to apply.",
            "category": "promotions",
        },
        {
            "question": "What is an eSIM?",
            "answer": "An eSIM is a digital SIM that lets you activate your Koodo plan without a physical SIM card. You scan a QR code during activation. eSIM is available for compatible devices on eligible 5G plans.",
            "category": "account",
        },
        {
            "question": "What network does Koodo use?",
            "answer": "Koodo operates on the TELUS network, Canada's largest 5G network, providing coast-to-coast coverage with 5G and 4G LTE speeds.",
            "category": "plans",
        },
        {
            "question": "Can I cancel my Koodo service?",
            "answer": "Yes, you can cancel anytime. If you have a Tab balance, you'll need to pay the remaining amount. If Koodo changes your plan price, you can cancel without penalty within 30 days of the change.",
            "category": "account",
        },
        {
            "question": "What are Certified Pre-Owned phones?",
            "answer": "Certified Pre-Owned (CPO) phones are like-new devices at lower prices, inspected and tested by Koodo. They come with a Limited Warranty for as long as you're a Koodo customer.",
            "category": "devices",
        },
        {
            "question": "What is Device Care Complete?",
            "answer": "Device Care Complete is protection for your phone that covers accidental damage, loss, and theft. It extends your phone's lifespan with worry-free protection.",
            "category": "devices",
        },
        {
            "question": "How do I contact Koodo support?",
            "answer": "Start with Koodo Assist (available 24/7) at koodomobile.com. You can also call 1-866-995-6636 (Mon-Fri 10am-9pm, Sat-Sun 9am-8pm ET), or ask the Koodo Community forum.",
            "category": "support",
        },
        {
            "question": "What streaming bundles does Koodo offer?",
            "answer": "Koodo offers Stream+ bundles including Apple TV starting from $20/month for the first 3 months. Bundle with your plan to save $10/month.",
            "category": "promotions",
        },
        {
            "question": "Is the $80 connection fee waived online?",
            "answer": "Yes, when you order online and sign up for Koodo's email deals, the $80 connection fee is waived. This is a web-exclusive offer.",
            "category": "promotions",
        },
    ],
}


if __name__ == "__main__":
    print(json.dumps(KOODO_EXTRACTION, indent=2))
