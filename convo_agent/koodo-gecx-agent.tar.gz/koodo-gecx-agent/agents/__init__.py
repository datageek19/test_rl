"""Koodo GECX Multi-Agent Pipeline."""
